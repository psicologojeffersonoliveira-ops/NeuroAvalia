import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";
export const onlineApplications = sqliteTable("online_applications", {
  applicationId:text("application_id").primaryKey(), applicationSessionId:text("application_session_id").notNull().unique(),
  patientId:text("patient_id").notNull(), evaluationId:text("evaluation_id").notNull(), testId:text("test_id").notNull(), respondentId:text("respondent_id"),
  batteryId:text("battery_id"), instrumentId:text("instrument_id"), protocolId:text("protocol_id"), respondentType:text("respondent_type"),
  professionalEmail:text("professional_email").notNull(), identifierHash:text("identifier_hash").notNull(), tokenHash:text("token_hash").notNull().unique(), accessKeyHash:text("access_key_hash"),
  identifierNameHash:text("identifier_name_hash"), identifierCpfHash:text("identifier_cpf_hash"), identifierBirthHash:text("identifier_birth_hash"),
  status:text("status").notNull().default("LIBERADA"), applicationMode:text("application_mode").notNull().default("AUTOPREENCHIMENTO_REMOTO"), formSpecJson:text("form_spec_json"), answersJson:text("answers_json"),
  createdAt:integer("created_at").notNull(), accessedAt:integer("accessed_at"), completedAt:integer("completed_at"), expiresAt:integer("expires_at").notNull(), closedAt:integer("closed_at")
});

export const neuroavaliaImports = sqliteTable("neuroavalia_imports", {
  importId: text("import_id").primaryKey(),
  professionalEmail: text("professional_email").notNull(),
  kind: text("kind").notNull(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size").notNull(),
  contentType: text("content_type").notNull(),
  sha256: text("sha256").notNull(),
  objectKey: text("object_key").notNull().unique(),
  status: text("status").notNull().default("ANALISADO"),
  analysisJson: text("analysis_json").notNull(),
  preservationJson: text("preservation_json"),
  previousImportId: text("previous_import_id"),
  previousSha256: text("previous_sha256"),
  errorJson: text("error_json"),
  restoredAt: integer("restored_at"),
  createdAt: integer("created_at").notNull(),
});

export const neuroavaliaActiveHtml = sqliteTable("neuroavalia_active_html", {
  professionalEmail: text("professional_email").primaryKey(),
  importId: text("import_id").notNull(),
  objectKey: text("object_key").notNull(),
  sha256: text("sha256").notNull(),
  previousImportId: text("previous_import_id"),
  previousObjectKey: text("previous_object_key"),
  previousSha256: text("previous_sha256"),
  activatedAt: integer("activated_at").notNull(),
});

export const neuroavaliaClinicalState = sqliteTable('neuroavalia_clinical_state', {
 professionalEmail:text('professional_email').primaryKey(),
 revision:text('revision').notNull(),
 objectKey:text('object_key').notNull(),
 updatedAt:integer('updated_at').notNull(),
});

export const neuroavaliaExportLogs = sqliteTable('neuroavalia_export_logs', {
 id:text('id').primaryKey(), professionalEmail:text('professional_email').notNull(), patientId:text('patient_id').notNull(),
 documentType:text('document_type').notNull(), format:text('format').notNull(), status:text('status').notNull(),
 buildVersion:text('build_version'), errorMessage:text('error_message'), createdAt:integer('created_at').notNull(),
});
