import PatientHub from "./hub";
export default async function PatientHubPage({params}:{params:Promise<{token:string}>}){const {token}=await params;return <PatientHub token={token}/>}
