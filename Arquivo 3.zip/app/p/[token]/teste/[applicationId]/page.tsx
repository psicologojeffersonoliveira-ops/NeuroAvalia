import RespondentPortal from "../../../../aplicacao/[token]/respondent";
export default async function PatientTestPage({params}:{params:Promise<{token:string;applicationId:string}>}){const {token,applicationId}=await params;return <RespondentPortal token={token} selectedApplicationId={applicationId} hub/>}
