import {attachCloudPersistence} from '../../../lib/neuro-cloud-persistence';
import {env} from "cloudflare:workers";
import {getChatGPTUser} from "../../../chatgpt-auth";
import baselineRaw from "../../../../protected/NEUROAVALIA_BASELINE_FUNCIONAL_INTEGRIDADE_LEANDRA_APROVADO_2026-08-22.html?raw";
import {injectBeforeClosingBody} from "../../../lib/html-injection";
import {neuroRestoreIntegration} from "../../../lib/neuro-restore-integration";
import {neuroRemoteIntegration} from "../../../lib/neuro-remote-integration";
import {neuroDocxAssets} from "../../../lib/neuro-docx-assets";
import {agendaOnline} from "../../../lib/agenda-online";
import {neuroIntegrityV43} from "../../../lib/neuro-integrity-v43";
import {neuroPipelineValidation} from '../../../lib/neuro-pipeline-validation';
import {neuroPatientReview} from '../../../lib/neuro-patient-review';
import {patientDiagnostics} from '../../../lib/patient-diagnostics';
import {neuroStartup} from "../../../lib/neuro-startup";
import {neuroCpfIntegration} from "../../../lib/neuro-cpf-integration";
import {anamnesisSemanticPhrase} from "../../../lib/anamnesis-narrative";
import {neuroPfisterProfessional} from "../../../lib/neuro-pfister-professional";

type Active={importId:string;objectKey:string;sha256:string;preservationJson?:string};
const FROZEN_HTML_SHA256="a12d7842e1bc6fcd963ca22a50000982bee4ae045e6121436258f07c18dc3973";
function literal(text:string,name:string,fallback:string){const match=text.match(new RegExp(`const\\s+${name}\\s*=\\s*['\"]([^'\"]+)['\"]`));return match?.[1]||fallback}
function safeJson(value:string){return JSON.stringify(value).replace(/</g,"\\u003c")}
function stripParallelReyAssist(html:string){
  /* Remove somente a implementação visual paralela. Os dados reyImageReview já
     persistidos permanecem intocados no estado clínico e podem ser recuperados
     de backups; o protocolo autoritativo original de Rey continua no HTML. */
  return html
    .replace(/<script\s+data-neuro-rey-image-assist[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<script\s+data-neuro-rey-inline-assist[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<style\s+data-neuro-rey-inline-assist[^>]*>[\s\S]*?<\/style>/g,"")
    .replace(/<script\s+data-neuro-rey-layout-fix[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<style\s+data-neuro-rey-layout-fix[^>]*>[\s\S]*?<\/style>/g,"");
}
function ensureCurrentOnlineIntegration(html:string,expectedPatients=0){
  html=html.replace(/\/\*NEURO_RECOVERY_GUARD_START\*\/[\s\S]*?\/\*NEURO_RECOVERY_GUARD_END\*\//g,"");
  if(Number.isFinite(expectedPatients)&&expectedPatients>0){const anchor="if(idbState&&typeof idbState==='object')";const guard="/*NEURO_RECOVERY_GUARD_START*/if(!idbState&&(db?.patients?.length||0)<"+expectedPatients+"){window.__NEURO_PERSISTENCE_READY__=false;window.__NEURO_RECOVERY_REQUIRED__=true;alert('A base principal deste navegador não foi localizada. O arquivo incorporado possui menos pacientes que a última preservação. O salvamento automático foi bloqueado para evitar substituir sua base. Use Diagnosticar pacientes.');return db;}/*NEURO_RECOVERY_GUARD_END*/";html=html.replace(anchor,guard+anchor)}
  /* O HTML restaurado continua sendo a fonte clínica. A camada online precisa
     ser aplicada a qualquer SHA ativo; antes ela só existia no SHA congelado,
     fazendo os botões desaparecerem após uma restauração válida. */
  const cleaned=html.replace(/<script\s+data-neuro-patient-diagnostics[^>]*>[\s\S]*?<\/script>/g,"").replace(/<script\s+data-neuro-patient-review[^>]*>[\s\S]*?<\/script>/g,"").replace(/\sdata-neuro-validation-source="[^"]*"/g,"")
    .replace(/<script\s+data-neuro-pipeline-validation[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<(script|style)\s+data-neuro-agenda-online[^>]*>[\s\S]*?<\/\1>/g,"")
    .replace(/<script\s+data-neuro-final-context-reset[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<(script|style)\s+data-neuro-online-startup[^>]*>[\s\S]*?<\/\1>/g,"")
    .replace(/<style\s+data-neuro-remote-style[^>]*>[\s\S]*?<\/style>/g,"")
    .replace(/<script\s+data-neuro-remote-integration[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<script\s+data-neuro-docx-assets[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<script\s+data-neuro-root-reliability[^>]*>[\s\S]*?<\/script>/g,"")
    .replace(/<script\s+data-neuro-export-audit[^>]*>[\s\S]*?<\/script>/g,"");
  return attachCloudPersistence(injectBeforeClosingBody(cleaned,neuroPfisterProfessional+neuroRemoteIntegration+neuroDocxAssets+neuroStartup+agendaOnline+neuroPipelineValidation+neuroPatientReview+patientDiagnostics+neuroCpfIntegration+neuroIntegrityV43));
}
function restoreKnownFrozenHtml(html:string,sha256:string){
  if(sha256!==FROZEN_HTML_SHA256)return html;
  const brokenStart=html.indexOf("function saveCompleteHTML(){");
  const nextScript=html.indexOf('<script hidden="" style="display: none;">',brokenStart);
  const approvedStart=baselineRaw.indexOf("function saveCompleteHTML(){");
  const approvedEnd=baselineRaw.indexOf("</script>",approvedStart);
  if(brokenStart<0||nextScript<0||approvedStart<0||approvedEnd<0)return html;
  const approvedTail=baselineRaw.slice(approvedStart,approvedEnd);
  let restored=html.slice(0,brokenStart)+approvedTail+"\n</script>\n"+html.slice(nextScript);
  restored=restored
    .replaceAll('ontoggle="rememberPaymentFolderV3(this)"','ontoggle="if(typeof rememberPaymentFolderV3===\'function\')rememberPaymentFolderV3(this)"')
    .replaceAll('ontoggle="rememberPaymentPatientV3(this,','ontoggle="if(typeof rememberPaymentPatientV3===\'function\')rememberPaymentPatientV3(this,');
  const fluencyDefinition=restored.indexOf("function updateFluencyCard(");
  const earlyFluencyStart=restored.indexOf("<script>setTimeout(()=>{let cards=[...document.querySelectorAll('.test-entry')]");
  if(earlyFluencyStart>=0&&earlyFluencyStart<fluencyDefinition){
    const earlyFluencyEnd=restored.indexOf("},0)</script>",earlyFluencyStart);
    if(earlyFluencyEnd>=0){
      const bodyStart=earlyFluencyStart+"<script>setTimeout(()=>{".length;
      const body=restored.slice(bodyStart,earlyFluencyEnd);
      restored=restored.slice(0,earlyFluencyStart)+"<script>addEventListener('load',()=>{"+body+"},{once:true})</script>"+restored.slice(earlyFluencyEnd+"},0)</script>".length);
    }
  }
  restored=restored
    .replace("wrapper?.querySelector(':scope > .neuro-open-test-row')?.remove();\n    if(!wrapper||(!record&&!battery))return;","if(!wrapper||(!record&&!battery))return;\n    wrapper.querySelectorAll(':scope > .neuro-open-test-row').forEach(existing=>{if(existing.dataset.testName===name)existing.remove()});")
    .replace("row.appendChild(button);wrapper.appendChild(row);","row.dataset.testName=name;row.appendChild(button);card.insertAdjacentElement('afterend',row);")
    .replace('<div class="field wide"><label>Encaminhado por</label><input id="encaminhamento" placeholder="Profissional, escola, família ou demanda espontânea" value=""></div>','<div class="field wide"><label>Encaminhado por</label><input id="encaminhamento" placeholder="Profissional, escola, família ou demanda espontânea" value=""></div><div class="field"><label>CPF</label><input id="cpfPaciente" inputmode="numeric" autocomplete="off" maxlength="14" placeholder="000.000.000-00"></div><div class="field"><label>Telefone/Celular</label><input id="telefoneCelular" inputmode="tel" autocomplete="tel" placeholder="(00) 00000-0000"></div><div class="field"><label>WhatsApp</label><input id="whatsapp" inputmode="tel" autocomplete="tel" placeholder="(00) 00000-0000"></div><div class="field wide"><label><input id="whatsappMesmoCelular" type="checkbox"> WhatsApp é o mesmo número do telefone/celular</label></div><div class="field wide"><label>E-mail</label><input id="emailPaciente" type="email" autocomplete="email" placeholder="paciente@exemplo.com"></div>')
    .replace("referral:q('encaminhamento').value});","referral:q('encaminhamento').value,cpf:q('cpfPaciente').value.replace(/\\D/g,''),phone:q('telefoneCelular').value.trim(),whatsapp:q('whatsappMesmoCelular').checked?q('telefoneCelular').value.trim():q('whatsapp').value.trim(),whatsappSameAsPhone:q('whatsappMesmoCelular').checked,email:q('emailPaciente').value.trim()});")
    .replace("encaminhamento:'referral'};","encaminhamento:'referral',cpfPaciente:'cpf',telefoneCelular:'phone',whatsapp:'whatsapp',emailPaciente:'email'};")
    .replace("Object.entries(map).forEach(([id,k])=>q(id).value=(k==='birth'||k==='evaluation')?formatDate(p[k]):p[k]||'');","Object.entries(map).forEach(([id,k])=>q(id).value=(k==='birth'||k==='evaluation')?formatDate(p[k]):p[k]||'');q('whatsappMesmoCelular').checked=!!p.whatsappSameAsPhone;q('whatsapp').disabled=!!p.whatsappSameAsPhone;if(p.whatsappSameAsPhone)q('whatsapp').value=p.phone||'';")
    .replace("Encaminhamento/solicitação: ${p.referral||''}","Encaminhamento/solicitação: ${p.referral||''}\\nTelefone/Celular: ${p.phone||''}\\nWhatsApp: ${p.whatsapp||''}\\nE-mail: ${p.email||''}");
  restored=restored.replaceAll("card.onclick=function(event){\n        if(event.target.closest('.mini-actions,button,a,input,select,textarea'))return;\n        openEvaluationPatient(card.dataset.patientId,card.dataset.evaluationId,event);\n      };","card.onclick=function(event){\n        if(event.target.closest('.mini-actions,button,a,input,select,textarea'))return;\n        if(card.classList.contains('expanded')){event.preventDefault();event.stopPropagation();card.classList.remove('expanded');card.setAttribute('aria-expanded','false');return}\n        openEvaluationPatient(card.dataset.patientId,card.dataset.evaluationId,event);\n      };");
  /* Preserva integralmente a abertura autoritativa no overlay. O fechamento é
     ligado ao próprio painel visual aberto (a superfície que substitui o cartão
     na viewport), sem disparar em controles internos e sem registrar listeners
     duplicados. */
  restored=restored.replace(
    "overlay.querySelector('.neuro-eval-close').onclick=()=>closeEvaluationOverlay();",
    "overlay.querySelector('.neuro-eval-close').onclick=()=>closeEvaluationOverlay();overlay.querySelector('#neuroEvaluationDialog').addEventListener('click',event=>{if(event.target.closest('button,a,input,select,textarea,label,.evaluation-stage,.mini-actions'))return;const card=movedEvaluationCard;closeEvaluationOverlay(true);if(card){card.classList.remove('expanded');card.setAttribute('aria-expanded','false')}});"
  );
  let styleIndex=0;restored=restored.replaceAll('id="neuro-global-report-chart-style"',()=>`id="neuro-global-report-chart-style-static-${++styleIndex}"`);
  restored=stripParallelReyAssist(restored);
  restored=restored.replace("  ['AC','Atenção','18 a 64 anos','adulto','Atenção concentrada.','referência'],\n","");
  const mechanicalPhrase="const phrase=(label,value)=>{let lower=label.replace(/^\\d+\\.\\s*/,'').replace(/\\?$/,'').toLocaleLowerCase('pt-BR');if(value==='Sim')return\`foi confirmada a informação referente a \${lower}\`;if(value==='Não')return\`foi registrada resposta negativa quanto a \${lower}\`;if(value==='Não sabe informar')return\`não foi possível precisar \${lower}\`;return\`quanto a \${lower}, foi registrado \${value}\`};";
  restored=restored.replace(mechanicalPhrase,'const phrase='+anamnesisSemanticPhrase.toString()+';');
  const integration=`<script data-neuro-contact-integration="2026-08-27">(()=>{const qn=id=>document.getElementById(id);function sync(){const same=qn('whatsappMesmoCelular'),phone=qn('telefoneCelular'),whatsapp=qn('whatsapp');if(!same||!phone||!whatsapp)return;whatsapp.disabled=same.checked;if(same.checked)whatsapp.value=phone.value}qn('whatsappMesmoCelular')?.addEventListener('change',sync);qn('telefoneCelular')?.addEventListener('input',sync);window.neuroPatientIdentity=p=>{p=p||(typeof current==='function'?current():null);return p?{patientId:p.id,name:p.name||'',birth:p.birth||'',phone:p.phone||'',whatsapp:p.whatsapp||'',email:p.email||''}:null};window.neuroNavidesPatientIdentity=id=>window.neuroPatientIdentity((window.db?.patients||[]).find(p=>String(p.id)===String(id)));const before=window.renderAnamnesis;if(typeof before==='function')window.renderAnamnesis=renderAnamnesis=function(){const r=before.apply(this,arguments),p=typeof current==='function'?current():null,form=qn('anamnesisForm');if(p&&form&&!form.querySelector('[data-cadastro-identity]')){const box=document.createElement('section');box.className='notice';box.dataset.cadastroIdentity=String(p.id);box.innerHTML='<b>Dados do Cadastro</b><p>Telefone/Celular: '+(p.phone||'')+'</p><p>WhatsApp: '+(p.whatsapp||'')+'</p><p>E-mail: '+(p.email||'')+'</p>';form.prepend(box)}return r};addEventListener('DOMContentLoaded',()=>{sync();try{if(typeof current==='function'&&current())renderAnamnesis()}catch(e){console.error('[NeuroAvalia cadastro→anamnese]',e)}},{once:true})})();<\/script>`;
  restored=injectBeforeClosingBody(restored,integration+neuroPfisterProfessional+neuroRemoteIntegration+neuroDocxAssets+neuroRestoreIntegration);
  return restored;
}
const baseline=ensureCurrentOnlineIntegration(restoreKnownFrozenHtml(baselineRaw,FROZEN_HTML_SHA256));
function bootstrap(importId:string,sha:string,target:{db:string;store:string;key:string}){const next=`/api/professional/neuroavalia?active=${encodeURIComponent(sha)}`;return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Restaurando NeuroAvalia</title><style>body{font:16px Arial;background:#eef3ef;color:#163634;display:grid;place-items:center;min-height:100vh;margin:0}.box{background:#fffdf8;border:1px solid #d9e2dd;border-radius:20px;padding:28px;max-width:520px}b{display:block;font:600 28px Georgia;margin-bottom:10px}</style></head><body><div class="box"><b>Restaurando backup</b><p>Preservando os dados clínicos e ativando a estrutura funcional selecionada.</p><p id="state">Preparando restauração…</p></div><script>(async()=>{const state=document.getElementById('state');try{const open=(name,store)=>new Promise((ok,fail)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(store))r.result.createObjectStore(store)};r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error)});const read=async(name,store,key)=>{const d=await open(name,store);return new Promise((ok,fail)=>{const t=d.transaction(store,'readonly'),r=t.objectStore(store).get(key);r.onsuccess=()=>{d.close();ok(r.result)};r.onerror=()=>{d.close();fail(r.error)}})};const write=async(name,store,key,value)=>{const d=await open(name,store);return new Promise((ok,fail)=>{const t=d.transaction(store,'readwrite');t.objectStore(store).put(value,key);t.oncomplete=()=>{d.close();ok(true)};t.onerror=()=>{d.close();fail(t.error)}})};const snapshot=await read('NeuroAvaliaOnlineRestoreVault','snapshots','current');if(!snapshot||!snapshot.db)throw new Error('Cópia clínica preservada não encontrada.');await write(${safeJson(target.db)},${safeJson(target.store)},${safeJson(target.key)},snapshot.db);sessionStorage.setItem('neuroavalia_restore_${sha}','prepared');state.textContent='Dados preservados. Reabrindo o NeuroAvalia…';location.replace(${safeJson(next)});}catch(error){state.textContent='FALHA NA RESTAURAÇÃO: '+(error&&error.message?error.message:String(error));fetch('/api/professional/imports/${encodeURIComponent(importId)}/confirm',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ok:false,message:state.textContent})}).catch(()=>{});}})();</script></body></html>`}
function confirmationScript(importId:string,sha:string,target:{db:string;store:string;key:string}){return `<script data-neuro-online-restore>(async()=>{if(sessionStorage.getItem('neuroavalia_restore_${sha}')!=='prepared')return;try{const d=await new Promise((ok,fail)=>{const r=indexedDB.open(${safeJson(target.db)},1);r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error)});const data=await new Promise((ok,fail)=>{const t=d.transaction(${safeJson(target.store)},'readonly'),r=t.objectStore(${safeJson(target.store)}).get(${safeJson(target.key)});r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error)});d.close();const patients=Array.isArray(data?.patients)?data.patients.length:0,evaluations=Array.isArray(data?.evaluations)?data.evaluations.length:patients,appointments=Array.isArray(data?.agenda)?data.agenda.length:0;const response=await fetch('/api/professional/imports/${encodeURIComponent(importId)}/confirm',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ok:true,patients,evaluations,appointments})});const result=await response.json();sessionStorage.setItem('neuroavalia_restore_${sha}',result.status||'finished');if(!response.ok)console.error('NeuroAvalia: '+(result.error||'rollback executado'));}catch(error){fetch('/api/professional/imports/${encodeURIComponent(importId)}/confirm',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ok:false,message:error?.message||String(error)})}).catch(()=>{});}})();</script>`}
async function validationSource(html:string){const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(html));return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('')}
export async function GET(request:Request){
  const user=await getChatGPTUser();
  if(!user)return new Response("Não autorizado",{status:401});
  const active=await env.DB.prepare("SELECT a.import_id importId,a.object_key objectKey,a.sha256,i.preservation_json preservationJson FROM neuroavalia_active_html a LEFT JOIN neuroavalia_imports i ON i.import_id=a.import_id AND i.professional_email=a.professional_email WHERE a.professional_email=?").bind(user.email).first<Active>();
  const headers={"content-type":"text/html; charset=utf-8","cache-control":"private, no-store","x-content-type-options":"nosniff"};
  if(!active)return new Response(baseline.replace('<html','<html data-neuro-validation-source="'+await validationSource(baseline)+'"'),{headers});
  let html:string,target:{db:string;store:string;key:string};
  if(active.sha256===FROZEN_HTML_SHA256){
    /* The active imported HTML is byte-identical to the frozen baseline. Reuse
       the module-level integrated result instead of loading and transforming a
       second 7.5 MB copy inside the Worker request. This prevents error 1101
       without changing the document, clinical data or active import record. */
    html=baseline;
    target={db:literal(html,"PERSIST_DB","NeuroAvaliaPersistentStore"),store:literal(html,"PERSIST_STORE","state"),key:literal(html,"PERSIST_KEY","neuroavalia_persist_v15")};
  }else{
    const object=await env.BUCKET.get(active.objectKey);
    if(!object)return new Response("A versão restaurada não foi encontrada. Abra Importação / Restauração para executar o rollback.",{status:503});
    let expectedPatients=0;
    try{expectedPatients=Number(JSON.parse(active.preservationJson||"{}").patients)||0}catch{}
    const storedHtml=await object.text();
    html=ensureCurrentOnlineIntegration(restoreKnownFrozenHtml(storedHtml,active.sha256),expectedPatients);
    target={db:literal(html,"PERSIST_DB","NeuroAvaliaPersistentStore"),store:literal(html,"PERSIST_STORE","state"),key:literal(html,"PERSIST_KEY","neuroavalia_persist_v15")};
  }
  const url=new URL(request.url);
  if(url.searchParams.get("restore")===active.importId)return new Response(bootstrap(active.importId,active.sha256,target),{headers:{"content-type":"text/html; charset=utf-8","cache-control":"private, no-store"}});
  const injected=injectBeforeClosingBody(html,confirmationScript(active.importId,active.sha256,target));
  return new Response(injected.replace('<html','<html data-neuro-validation-source="'+await validationSource(html)+'"'),{headers:{...headers,"x-neuroavalia-active-sha256":active.sha256,"x-neuroavalia-html-restored":active.sha256===FROZEN_HTML_SHA256?"true":"false","x-neuroavalia-online-integration":"current"}});
}
