import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import backupRaw from "../../../../protected/recovery/2026-08-28.json?raw";
import {
  validClinicalState,
  RECOVERY_VERSION,
} from "../../../lib/clinical-state";
const OWNER = "jeffersonpsicofenomenologia@gmail.com";
const json = (body: unknown, status = 200) =>
  Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
async function latest(email: string) {
  return env.DB.prepare(
    "SELECT revision, object_key objectKey, updated_at updatedAt FROM neuroavalia_clinical_state WHERE professional_email=?",
  )
    .bind(email)
    .first<{ revision: string; objectKey: string; updatedAt: number }>();
}
export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: "Não autorizado" }, 401);
  if (user.email.toLowerCase() !== OWNER)
    return json({ error: "Acesso restrito ao profissional responsável." }, 403);
  const row = await latest(user.email);
  let state = null;
  if (row) {
    const object = await env.BUCKET.get(row.objectKey);
    if (!object)
      return json(
        {
          error:
            "A cópia do servidor não foi localizada. Nenhuma base foi substituída.",
        },
        503,
      );
    state = JSON.parse(await object.text());
  }
  return json({
    revision: row?.revision || null,
    savedAt: row?.updatedAt ? new Date(row.updatedAt).toISOString() : null,
    state,
    recovery:
      state?.neuroRecoveryVersion === RECOVERY_VERSION
        ? null
        : JSON.parse(backupRaw).db,
  });
}
export async function PUT(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: "Não autorizado" }, 401);
  if (user.email.toLowerCase() !== OWNER)
    return json({ error: "Acesso restrito ao profissional responsável." }, 403);
  if (
    request.headers.get("origin") &&
    request.headers.get("origin") !== new URL(request.url).origin
  )
    return json({ error: "Origem não autorizada" }, 403);
  let input;
  try {
    const raw = await request.text();
    if (raw.length > 40_000_000)
      return json({ error: "Base excede o limite de salvamento." }, 413);
    input = JSON.parse(raw);
  } catch {
    return json({ error: "Dados inválidos" }, 400);
  }
  if (
    !validClinicalState(input.state) ||
    !(input.revision === null || typeof input.revision === "string")
  )
    return json({ error: "Base clínica inválida" }, 422);
  const row = await latest(user.email);
  if ((row?.revision || null) !== input.revision)
    return json(
      {
        error:
          "Outra janela salvou uma versão mais recente. Seus dados locais foram preservados.",
      },
      409,
    );
  const ownerHash = Array.from(
    new Uint8Array(
      await crypto.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(user.email),
      ),
    ),
  )
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  // Immutable snapshots preserve previous versions even when the pointer advances.
  const revision = crypto.randomUUID(),
    savedAt = Date.now(),
    objectKey = "clinical-state/" + ownerHash + "/" + revision + ".json",
    serialized = JSON.stringify(input.state);
  await env.BUCKET.put(objectKey, serialized, {
    httpMetadata: { contentType: "application/json" },
  });
  const verified = await env.BUCKET.get(objectKey);
  if (!verified || (await verified.text()) !== serialized)
    return json({ error: "O armazenamento não confirmou o salvamento." }, 503);
  const result = row
    ? await env.DB.prepare(
        "UPDATE neuroavalia_clinical_state SET revision=?,object_key=?,updated_at=? WHERE professional_email=? AND revision=?",
      )
        .bind(revision, objectKey, savedAt, user.email, input.revision)
        .run()
    : await env.DB.prepare(
        "INSERT INTO neuroavalia_clinical_state(professional_email,revision,object_key,updated_at) VALUES(?,?,?,?) ON CONFLICT(professional_email) DO NOTHING",
      )
        .bind(user.email, revision, objectKey, savedAt)
        .run();
  if (!result.meta.changes)
    return json(
      {
        error: "Conflito de salvamento. A versão mais recente foi preservada.",
      },
      409,
    );
  return json({ ok: true, revision, savedAt: new Date(savedAt).toISOString() });
}
