import { getChatGPTUser } from "../../../../chatgpt-auth";
import {
  calculatePfister,
  isPfisterProtocolComplete,
  pfisterReportRows,
  validatePfisterProtocol,
  type PfisterProtocol,
} from "../../../../lib/pfister-engine";

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
  let protocol: PfisterProtocol;
  try {
    protocol = (await request.json()).protocol as PfisterProtocol;
    validatePfisterProtocol(protocol);
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Protocolo Pfister inválido." },
      { status: 400 },
    );
  }
  const result = calculatePfister(protocol);
  if (!isPfisterProtocolComplete(protocol))
    return Response.json(
      { error: "Conclua as três pirâmides e todos os campos do inquérito antes da correção." },
      { status: 422 },
    );
  return Response.json({
    result,
    reportResultRows: pfisterReportRows(result),
    correctedAt: Date.now(),
  });
}
