import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../../chatgpt-auth';
function json(value:unknown,status=200){return new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json','cache-control':'no-store'}})}
export async function POST(request:Request){
 const user=await getChatGPTUser();if(!user)return json({error:'Não autorizado'},401);
 let body:any;try{body=await request.json()}catch{return json({error:'JSON inválido'},400)}
 const allowed=new Set(['pages-docx','docx','pdf','print']);
 if(!allowed.has(body?.format)||!['success','failure'].includes(body?.status))return json({error:'Registro inválido'},400);
 const id=crypto.randomUUID(),createdAt=Date.now();
 await env.DB.prepare('INSERT INTO neuroavalia_export_logs (id,professional_email,patient_id,document_type,format,status,build_version,error_message,created_at) VALUES (?,?,?,?,?,?,?,?,?)').bind(id,user.email,String(body.patientId||''),String(body.documentType||'laudo').slice(0,80),body.format,body.status,String(body.buildVersion||'').slice(0,40),body.error?String(body.error).slice(0,500):null,createdAt).run();
 return json({ok:true,id,createdAt});
}
