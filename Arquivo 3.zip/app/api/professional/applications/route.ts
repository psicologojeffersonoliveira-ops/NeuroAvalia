import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { digest, secret, shortSecret } from "../../../lib/crypto";
import { taggedIdentifier } from "../../../lib/respondent-identity";
const REMOTE_INSTRUMENTS = { has: (value: string) => Boolean(value.trim()) };
type FormField = {
  key: string;
  label: string;
  type:
    | "radio"
    | "checkbox"
    | "select"
    | "text"
    | "number"
    | "textarea"
    | "drawing";
  required?: boolean;
  options?: Array<{ value: string; label: string }>;
  imageUrl?: string;
};
function validSpec(
  value: unknown,
): value is { title: string; instructions?: string; fields: FormField[] } {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.title === "string" &&
    Array.isArray(v.fields) &&
    v.fields.length > 0 &&
    v.fields.length <= 300 &&
    v.fields.every((f) => {
      if (!f || typeof f !== "object") return false;
      const x = f as Record<string, unknown>;
      return (
        typeof x.key === "string" &&
        x.key.length <= 180 &&
        typeof x.label === "string" &&
        x.label.length <= 1000 &&
        [
          "radio",
          "checkbox",
          "select",
          "text",
          "number",
          "textarea",
          "drawing",
        ].includes(String(x.type)) &&
        (!x.imageUrl ||
          (typeof x.imageUrl === "string" &&
            x.imageUrl.startsWith("/materials/") &&
            x.imageUrl.length < 300))
      );
    })
  );
}
export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const patientId = params.get("patientId"),
    evaluationId = params.get("evaluationId");
  if (patientId && evaluationId) {
    const offset = Math.max(0, Number(params.get("offset")) || 0);
    const q = await env.DB.prepare(
      "SELECT application_id applicationId,patient_id patientId,evaluation_id evaluationId,test_id testId,protocol_id protocolId,respondent_type respondentType,status,answers_json answersJson,form_spec_json formSpecJson,created_at createdAt,completed_at completedAt FROM online_applications WHERE professional_email=? AND patient_id=? AND evaluation_id=? ORDER BY created_at DESC,application_id DESC LIMIT 21 OFFSET ?",
    )
      .bind(user.email, patientId, evaluationId, offset)
      .all<Record<string, unknown>>();
    return Response.json(
      {
        applications: q.results
          .slice(0, 20)
          .map((r: Record<string, unknown>) => ({
            ...r,
            answers: r.answersJson ? JSON.parse(String(r.answersJson)) : null,
            formSpec: JSON.parse(String(r.formSpecJson)),
            answersJson: undefined,
            formSpecJson: undefined,
          })),
        nextOffset: q.results.length > 20 ? offset + 20 : null,
      },
      { headers: { "cache-control": "private, no-store" } },
    );
  }
  const applicationId = params.get("applicationId");
  if (applicationId) {
    const row = await env.DB.prepare(
      "SELECT application_id applicationId,application_session_id applicationSessionId,patient_id patientId,evaluation_id evaluationId,battery_id batteryId,instrument_id instrumentId,protocol_id protocolId,test_id testId,respondent_id respondentId,respondent_type respondentType,status,answers_json answersJson,completed_at completedAt FROM online_applications WHERE professional_email=? AND application_id=?",
    )
      .bind(user.email, applicationId)
      .first<Record<string, unknown>>();
    return Response.json({
      applications: row
        ? [
            {
              ...row,
              answers: row.answersJson
                ? JSON.parse(String(row.answersJson))
                : null,
              answersJson: undefined,
            },
          ]
        : [],
    });
  }
  const q = await env.DB.prepare(
    "SELECT application_id applicationId,application_session_id applicationSessionId,patient_id patientId,evaluation_id evaluationId,battery_id batteryId,instrument_id instrumentId,protocol_id protocolId,respondent_id respondentId,respondent_type respondentType,test_id testId,status,answers_json answersJson,created_at createdAt,completed_at completedAt FROM online_applications WHERE professional_email=? ORDER BY created_at DESC LIMIT 100",
  )
    .bind(user.email)
    .all<Record<string, unknown>>();
  return Response.json({
    applications: q.results.map((r) => ({
      ...r,
      answers: r.answersJson ? JSON.parse(String(r.answersJson)) : null,
      answersJson: undefined,
    })),
  });
}
export async function POST(req: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
  const p = (await req.json()) as Record<string, unknown>,
    identifiers = (p.identifiers || {}) as Record<string, unknown>;
  const testId = String(p.testId || ""),
    legacy = String(
      p.identifier ||
        identifiers.name ||
        identifiers.cpf ||
        identifiers.birth ||
        p.identifier ||
        "",
    );
  const tagged = {
    name: taggedIdentifier(
      "name",
      String(identifiers.name || p.identifier || ""),
    ),
    cpf: taggedIdentifier("cpf", String(identifiers.cpf || "")),
    birth: taggedIdentifier("birth", String(identifiers.birth || "")),
  };
  if (
    !p.patientId ||
    !p.evaluationId ||
    !legacy ||
    !Object.values(tagged).some(Boolean) ||
    !p.protocolId ||
    !p.instrumentId ||
    !REMOTE_INSTRUMENTS.has(testId) ||
    !validSpec(p.formSpec)
  )
    return Response.json(
      {
        error:
          "Instrumento, protocolo ou identificação autoritativa indisponível para envio.",
      },
      { status: 400 },
    );
  const formSpecJson = JSON.stringify(p.formSpec);
  if (formSpecJson.length > 500000)
    return Response.json(
      { error: "Protocolo excede o limite seguro de envio." },
      { status: 413 },
    );
  const applicationId = crypto.randomUUID(),
    applicationSessionId = crypto.randomUUID(),
    token = shortSecret(),
    now = Date.now(),
    expires = now + 30 * 86400000;
  await env.DB.prepare(
    "INSERT INTO online_applications(application_id,application_session_id,patient_id,evaluation_id,battery_id,instrument_id,protocol_id,test_id,respondent_id,respondent_type,professional_email,identifier_hash,identifier_name_hash,identifier_cpf_hash,identifier_birth_hash,token_hash,status,application_mode,form_spec_json,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'LIBERADA','AUTOPREENCHIMENTO_REMOTO',?,?,?)",
  )
    .bind(
      applicationId,
      applicationSessionId,
      String(p.patientId),
      String(p.evaluationId),
      p.batteryId ? String(p.batteryId) : null,
      String(p.instrumentId),
      String(p.protocolId),
      testId,
      p.respondentId ? String(p.respondentId) : null,
      p.respondentType ? String(p.respondentType) : null,
      user.email,
      await digest(legacy),
      tagged.name ? await digest(tagged.name) : null,
      tagged.cpf ? await digest(tagged.cpf) : null,
      tagged.birth ? await digest(tagged.birth) : null,
      await digest(token),
      formSpecJson,
      now,
      expires,
    )
    .run();
  const origin = new URL(req.url).origin;
  return Response.json(
    {
      application: {
        applicationId,
        applicationSessionId,
        patientId: p.patientId,
        evaluationId: p.evaluationId,
        batteryId: p.batteryId || null,
        instrumentId: p.instrumentId,
        protocolId: p.protocolId,
        testId,
        status: "LIBERADA",
        createdAt: now,
        expiresAt: expires,
        link: `${origin}/p/${token}`,
      },
    },
    { status: 201 },
  );
}
