import {env} from "cloudflare:workers";
import {getChatGPTUser} from "../../../../../chatgpt-auth";

type Preservation={vaultConfirmed?:boolean;patients?:number;evaluations?:number;appointments?:number;capturedAt?:number};
function validHtml(text:string){return /<!doctype\s+html/i.test(text)&&/<html\b/i.test(text)&&/<body\b/i.test(text)&&/<script\b/i.test(text)&&/NeuroAvalia/i.test(text)}

export async function POST(request:Request,context:{params:Promise<{id:string}>}){
  const user=await getChatGPTUser();if(!user)return Response.json({error:"Não autorizado"},{status:401});
  const {id}=await context.params;const preservation=await request.json() as Preservation;
  if(!preservation.vaultConfirmed)return Response.json({error:"A cópia de segurança dos dados atuais não foi confirmada. Restauração cancelada."},{status:409});
  const imported=await env.DB.prepare("SELECT import_id importId, object_key objectKey, sha256, kind, status FROM neuroavalia_imports WHERE import_id=? AND professional_email=?").bind(id,user.email).first<{importId:string;objectKey:string;sha256:string;kind:string;status:string}>();
  if(!imported||imported.kind!=="html")return Response.json({error:"Backup HTML não encontrado."},{status:404});
  const object=await env.BUCKET.get(imported.objectKey);if(!object)return Response.json({error:"Arquivo importado não encontrado no armazenamento."},{status:404});
  const text=await object.text();if(!validHtml(text)){await env.DB.prepare("UPDATE neuroavalia_imports SET status='FALHA NA RESTAURAÇÃO', error_json=? WHERE import_id=? AND professional_email=?").bind(JSON.stringify({stage:"VALIDAR HTML",message:"O arquivo não contém a estrutura completa reconhecida do NeuroAvalia."}),id,user.email).run();return Response.json({error:"O HTML não contém uma estrutura completa reconhecida do NeuroAvalia."},{status:422})}
  const active=await env.DB.prepare("SELECT import_id importId, object_key objectKey, sha256 FROM neuroavalia_active_html WHERE professional_email=?").bind(user.email).first<{importId:string;objectKey:string;sha256:string}>();
  const now=Date.now();
  await env.DB.batch([
    env.DB.prepare("UPDATE neuroavalia_imports SET status='RESTAURANDO', preservation_json=?, previous_import_id=?, previous_sha256=?, error_json=NULL WHERE import_id=? AND professional_email=?").bind(JSON.stringify(preservation),active?.importId||null,active?.sha256||"BASELINE_PROTEGIDO",id,user.email),
    env.DB.prepare("INSERT INTO neuroavalia_active_html(professional_email,import_id,object_key,sha256,previous_import_id,previous_object_key,previous_sha256,activated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(professional_email) DO UPDATE SET import_id=excluded.import_id,object_key=excluded.object_key,sha256=excluded.sha256,previous_import_id=excluded.previous_import_id,previous_object_key=excluded.previous_object_key,previous_sha256=excluded.previous_sha256,activated_at=excluded.activated_at").bind(user.email,id,imported.objectKey,imported.sha256,active?.importId||null,active?.objectKey||null,active?.sha256||"BASELINE_PROTEGIDO",now),
  ]);
  return Response.json({status:"RESTAURANDO",reloadUrl:`/api/professional/neuroavalia?restore=${encodeURIComponent(id)}`});
}
