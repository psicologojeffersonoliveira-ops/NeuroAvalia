import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../../chatgpt-auth";

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
  const { id } = await context.params;
  const active = await env.DB.prepare("SELECT import_id importId, previous_import_id previousImportId FROM neuroavalia_active_html WHERE professional_email=?").bind(user.email).first<{ importId: string; previousImportId: string | null }>();
  if (active?.importId === id || active?.previousImportId === id) return Response.json({ error: "Esta versão participa da restauração ou do rollback atual e não pode ser excluída." }, { status: 409 });
  const row = await env.DB.prepare("SELECT object_key objectKey FROM neuroavalia_imports WHERE import_id=? AND professional_email=?").bind(id, user.email).first<{ objectKey: string }>();
  if (!row) return Response.json({ error: "Importação não encontrada." }, { status: 404 });
  await env.BUCKET.delete(row.objectKey);
  await env.DB.prepare("DELETE FROM neuroavalia_imports WHERE import_id=? AND professional_email=?").bind(id, user.email).run();
  return Response.json({ deleted: true, currentSystemChanged: false, clinicalDataChanged: false });
}
