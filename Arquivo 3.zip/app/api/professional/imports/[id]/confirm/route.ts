import {env} from "cloudflare:workers";
import {getChatGPTUser} from "../../../../../chatgpt-auth";

type Confirmation={ok?:boolean;patients?:number;evaluations?:number;appointments?:number;message?:string};
export async function POST(request:Request,context:{params:Promise<{id:string}>}){
  const user=await getChatGPTUser();if(!user)return Response.json({error:"Não autorizado"},{status:401});
  const {id}=await context.params;const confirmation=await request.json() as Confirmation;
  const active=await env.DB.prepare("SELECT import_id importId, previous_import_id previousImportId, previous_object_key previousObjectKey, previous_sha256 previousSha256 FROM neuroavalia_active_html WHERE professional_email=?").bind(user.email).first<{importId:string;previousImportId:string|null;previousObjectKey:string|null;previousSha256:string|null}>();
  if(!active||active.importId!==id)return Response.json({error:"Esta restauração não é mais a versão ativa."},{status:409});
  const imported=await env.DB.prepare("SELECT preservation_json preservationJson FROM neuroavalia_imports WHERE import_id=? AND professional_email=?").bind(id,user.email).first<{preservationJson:string}>();
  const expected=imported?.preservationJson?JSON.parse(imported.preservationJson) as Confirmation:{};
  const countsMatch=confirmation.ok===true&&confirmation.patients===expected.patients&&confirmation.evaluations===expected.evaluations&&confirmation.appointments===expected.appointments;
  if(countsMatch){await env.DB.prepare("UPDATE neuroavalia_imports SET status='RESTAURADO', restored_at=?, error_json=NULL WHERE import_id=? AND professional_email=?").bind(Date.now(),id,user.email).run();return Response.json({status:"RESTAURADO"})}
  const error=JSON.stringify({stage:"VALIDAR DADOS APÓS REABERTURA",message:confirmation.message||"As contagens preservadas divergiram após a restauração.",expected,received:confirmation});
  if(active.previousImportId&&active.previousObjectKey&&active.previousSha256){await env.DB.batch([env.DB.prepare("UPDATE neuroavalia_active_html SET import_id=?,object_key=?,sha256=?,previous_import_id=NULL,previous_object_key=NULL,previous_sha256=NULL,activated_at=? WHERE professional_email=?").bind(active.previousImportId,active.previousObjectKey,active.previousSha256,Date.now(),user.email),env.DB.prepare("UPDATE neuroavalia_imports SET status='ROLLBACK EXECUTADO', error_json=? WHERE import_id=? AND professional_email=?").bind(error,id,user.email)]);}else{await env.DB.batch([env.DB.prepare("DELETE FROM neuroavalia_active_html WHERE professional_email=?").bind(user.email),env.DB.prepare("UPDATE neuroavalia_imports SET status='ROLLBACK EXECUTADO', error_json=? WHERE import_id=? AND professional_email=?").bind(error,id,user.email)]);}
  return Response.json({status:"ROLLBACK EXECUTADO",error:"A validação falhou e a versão estrutural anterior foi restaurada."},{status:409});
}
