import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import baseline from "../../../../protected/NEUROAVALIA_BASELINE_FUNCIONAL_INTEGRIDADE_LEANDRA_APROVADO_2026-08-22.html?raw";
import { analyzeHtml, analyzeJson, type ImportKind } from "../../../lib/import-analysis";

export const dynamic = "force-dynamic";
const MAX_BYTES = 25 * 1024 * 1024;

function hex(bytes: ArrayBuffer) { return [...new Uint8Array(bytes)].map(value => value.toString(16).padStart(2, "0")).join(""); }
function safeFileName(value: string) { return value.replace(/[^A-Za-z0-9._-]+/g, "_").slice(-180) || "arquivo"; }

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
  const result = await env.DB.prepare("SELECT import_id importId, kind, file_name fileName, file_size fileSize, content_type contentType, sha256, status, analysis_json analysisJson, error_json errorJson, restored_at restoredAt, created_at createdAt FROM neuroavalia_imports WHERE professional_email=? ORDER BY created_at DESC LIMIT 100").bind(user.email).all();
  return Response.json({ imports: result.results.map(row => ({ ...row, analysis: JSON.parse(String(row.analysisJson)), analysisJson: undefined })) });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
  const form = await request.formData();
  const file = form.get("file");
  const kind = form.get("kind") as ImportKind | null;
  if (!(file instanceof File) || (kind !== "html" && kind !== "json")) return Response.json({ error: "Arquivo e tipo são obrigatórios." }, { status: 400 });
  const extension = file.name.toLowerCase().split(".").pop();
  if ((kind === "html" && extension !== "html") || (kind === "json" && extension !== "json")) return Response.json({ error: `Selecione um arquivo .${kind}.` }, { status: 400 });
  if (!file.size || file.size > MAX_BYTES) return Response.json({ error: "O arquivo deve ter entre 1 byte e 25 MB." }, { status: 413 });
  const bytes = await file.arrayBuffer();
  const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  let analysis: unknown;
  try { analysis = kind === "html" ? analyzeHtml(text, baseline) : analyzeJson(text); }
  catch { return Response.json({ error: kind === "json" ? "JSON inválido ou ilegível." : "HTML ilegível." }, { status: 400 }); }
  const sha256 = hex(await crypto.subtle.digest("SHA-256", bytes));
  const importId = crypto.randomUUID(), createdAt = Date.now();
  const objectKey = `neuroavalia-imports/${encodeURIComponent(user.email)}/${importId}/${safeFileName(file.name)}`;
  await env.BUCKET.put(objectKey, bytes, { httpMetadata: { contentType: file.type || (kind === "html" ? "text/html" : "application/json") }, customMetadata: { sha256, kind } });
  try {
    await env.DB.prepare("INSERT INTO neuroavalia_imports(import_id,professional_email,kind,file_name,file_size,content_type,sha256,object_key,status,analysis_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)").bind(importId, user.email, kind, file.name, file.size, file.type || "application/octet-stream", sha256, objectKey, kind === "html" ? "ANÁLISE CONCLUÍDA" : "ANALISADO", JSON.stringify(analysis), createdAt).run();
  } catch (error) {
    await env.BUCKET.delete(objectKey);
    throw error;
  }
  return Response.json({ import: { importId, kind, fileName: file.name, fileSize: file.size, sha256, status: kind === "html" ? "ANÁLISE CONCLUÍDA" : "ANALISADO", analysis, createdAt } }, { status: 201 });
}
