import {env} from "cloudflare:workers";
import {digest} from "../../../lib/crypto";
import {IdentifierKind,taggedIdentifier} from "../../../lib/respondent-identity";

type HubRequest={token?:string;identifier?:string;identifierKind?:IdentifierKind};
export async function POST(req:Request){
 const p=await req.json() as HubRequest;if(!p.token||!p.identifier)return Response.json({error:"Identificação obrigatória."},{status:400});
 const kind=p.identifierKind||"name",tagged=taggedIdentifier(kind,p.identifier);if(!tagged)return Response.json({error:"Identificação inválida."},{status:400});
 const anchor=await env.DB.prepare("SELECT patient_id patientId,evaluation_id evaluationId,professional_email professionalEmail,identifier_hash identifierHash,identifier_name_hash identifierNameHash,identifier_cpf_hash identifierCpfHash,identifier_birth_hash identifierBirthHash,expires_at expiresAt FROM online_applications WHERE token_hash=?").bind(await digest(p.token)).first<Record<string,unknown>>();
 if(!anchor)return Response.json({error:"Acesso inválido."},{status:404});if(Number(anchor.expiresAt)<Date.now())return Response.json({error:"Este acesso expirou. Solicite um novo link ao profissional."},{status:410});
 const expected=kind==="cpf"?anchor.identifierCpfHash:kind==="birth"?anchor.identifierBirthHash:anchor.identifierNameHash;if(expected!==await digest(tagged)&&anchor.identifierHash!==await digest(p.identifier))return Response.json({error:"Identificação não conferida."},{status:403});
 const q=await env.DB.prepare("SELECT application_id applicationId,test_id testId,status,created_at createdAt,completed_at completedAt FROM online_applications WHERE patient_id=? AND evaluation_id=? AND professional_email=? AND expires_at>=? AND status IN ('LIBERADA','EM ANDAMENTO','CONCLUÍDA') ORDER BY created_at DESC,application_id DESC").bind(anchor.patientId,anchor.evaluationId,anchor.professionalEmail,Date.now()).all<Record<string,unknown>>();
 const unique=[...new Map(q.results.map(x=>[String(x.testId),x])).values()].reverse();
 return Response.json({professional:"Jefferson Oliveira",message:"Você recebeu uma avaliação do neuropsicólogo Jefferson Oliveira",tests:unique.map(x=>({...x,available:x.status==="LIBERADA"}))},{headers:{"cache-control":"private, no-store"}});
}
