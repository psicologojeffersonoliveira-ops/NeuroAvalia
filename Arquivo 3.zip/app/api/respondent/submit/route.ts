import { validDrawing } from "../../../lib/drawing-response";
import { env } from "cloudflare:workers";
import { digest } from "../../../lib/crypto";
type Field = {
  key: string;
  type: string;
  required?: boolean;
  options?: Array<{ value: string }>;
};
async function saveAnswers(req: Request, partial = false) {
  const p = (await req.json()) as {
    token?: string;
    applicationId?: string;
    accessKey?: string;
    answers?: Record<string, string | boolean>;
  };
  if (
    !p.token ||
    !p.accessKey ||
    !p.answers ||
    typeof p.answers !== "object" ||
    JSON.stringify(p.answers).length > 1500000
  )
    return Response.json(
      { error: "Sessão incompleta ou excede o limite seguro." },
      { status: 400 },
    );
  const tokenHash = await digest(p.token),
    accessHash = await digest(p.accessKey);
  const row = p.applicationId
    ? await env.DB.prepare(
        "SELECT status,access_key_hash accessKeyHash,form_spec_json formSpecJson FROM online_applications WHERE application_id=?",
      )
        .bind(p.applicationId)
        .first<Record<string, unknown>>()
    : await env.DB.prepare(
        "SELECT status,access_key_hash accessKeyHash,form_spec_json formSpecJson FROM online_applications WHERE token_hash=?",
      )
        .bind(tokenHash)
        .first<Record<string, unknown>>();
  if (!row)
    return Response.json({ error: "Sessão inválida." }, { status: 404 });
  if (row.status === "CONCLUÍDA")
    return Response.json(
      { error: "Esta avaliação já foi finalizada." },
      { status: 409 },
    );
  if (row.status !== "EM ANDAMENTO" || row.accessKeyHash !== accessHash)
    return Response.json({ error: "Sessão não autorizada." }, { status: 403 });
  let fields: Field[];
  try {
    fields = JSON.parse(String(row.formSpecJson)).fields;
  } catch {
    return Response.json({ error: "Protocolo inválido." }, { status: 503 });
  }
  const keys = new Set(fields.map((f) => f.key));
  if (
    fields.some(
      (f) =>
        f.type === "drawing" &&
        p.answers?.[f.key] !== undefined &&
        !validDrawing(p.answers[f.key]),
    )
  )
    return Response.json(
      {
        error: "Folha de traços inválida. Reabra a aplicação antes de enviar.",
      },
      { status: 400 },
    );
  if (
    Object.keys(p.answers).some((k) => !keys.has(k)) ||
    fields.some(
      (f) =>
        !partial &&
        f.required &&
        f.type !== "drawing" &&
        (p.answers?.[f.key] === undefined || p.answers?.[f.key] === ""),
    ) ||
    fields.some(
      (f) =>
        f.options?.length &&
        p.answers?.[f.key] !== undefined &&
        !f.options.some((o) => String(o.value) === String(p.answers?.[f.key])),
    )
  )
    return Response.json(
      { error: "Respostas incompletas ou inválidas." },
      { status: 400 },
    );
  if (partial) {
    const result = p.applicationId
      ? await env.DB.prepare(
          "UPDATE online_applications SET answers_json=? WHERE application_id=? AND access_key_hash=? AND status='EM ANDAMENTO'",
        )
          .bind(JSON.stringify(p.answers), p.applicationId, accessHash)
          .run()
      : await env.DB.prepare(
          "UPDATE online_applications SET answers_json=? WHERE token_hash=? AND access_key_hash=? AND status='EM ANDAMENTO'",
        )
          .bind(JSON.stringify(p.answers), tokenHash, accessHash)
          .run();
    return result.meta.changes
      ? Response.json({ ok: true, savedAt: Date.now() })
      : Response.json({ error: "Sessão encerrada." }, { status: 409 });
  }
  const completed = p.applicationId
    ? await env.DB.prepare(
        "UPDATE online_applications SET answers_json=?,status='CONCLUÍDA',completed_at=?,closed_at=? WHERE application_id=? AND access_key_hash=? AND status='EM ANDAMENTO'",
      )
        .bind(
          JSON.stringify(p.answers),
          Date.now(),
          Date.now(),
          p.applicationId,
          accessHash,
        )
        .run()
    : await env.DB.prepare(
        "UPDATE online_applications SET answers_json=?,status='CONCLUÍDA',completed_at=?,closed_at=? WHERE token_hash=? AND access_key_hash=? AND status='EM ANDAMENTO'",
      )
        .bind(
          JSON.stringify(p.answers),
          Date.now(),
          Date.now(),
          tokenHash,
          accessHash,
        )
        .run();
  return completed.meta.changes
    ? Response.json({ ok: true })
    : Response.json(
        {
          error:
            "Conclusão não confirmada: a sessão foi encerrada ou já finalizada.",
        },
        { status: 409 },
      );
}

export async function POST(req: Request) {
  return saveAnswers(req);
}
export async function PATCH(req: Request) {
  return saveAnswers(req, true);
}
