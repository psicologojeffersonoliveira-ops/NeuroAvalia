import {requireChatGPTUser} from '../../chatgpt-auth';
import Preview from './preview';
export const dynamic='force-dynamic';
export default async function Page(){await requireChatGPTUser('/profissional/visualizar');return <Preview/>}
