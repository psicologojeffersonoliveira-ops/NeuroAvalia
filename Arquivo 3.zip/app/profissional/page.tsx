import { redirect } from "next/navigation";
import { requireChatGPTUser } from "../chatgpt-auth";
export const dynamic="force-dynamic";
export default async function ProfessionalPage(){await requireChatGPTUser("/api/professional/neuroavalia");redirect("/api/professional/neuroavalia")}
