import {requireChatGPTUser} from '../../chatgpt-auth';
import ImportRestoration from '../import-restoration';
import '../../import-area.css';
import '../../restore-stage.css';
export const dynamic='force-dynamic';
export default async function Page(){await requireChatGPTUser('/profissional/importacao');return <main style={{padding:24,maxWidth:1200,margin:'auto'}}><a href="/api/professional/neuroavalia">← Voltar ao NeuroAvalia</a><ImportRestoration/></main>}
