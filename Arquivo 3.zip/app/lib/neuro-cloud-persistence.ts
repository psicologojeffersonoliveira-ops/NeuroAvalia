import {
  recoverMissingPatients,
  chooseClinicalState,
  mergeClinicalState,
} from "./clinical-state";
export const neuroCloudPersistence = String.raw`<script data-neuro-cloud-persistence>(()=>{'use strict';
if(typeof location!=='undefined'&&location.protocol==='file:'){window.neuroCloud={hydrate:async(local,fallback)=>local||fallback,save:async(localSave)=>localSave(),confirmHydration:async()=>{}};return}
const recover=${recoverMissingPatients.toString()},choose=${chooseClinicalState.toString()},merge=${mergeClinicalState.toString()};
const endpoint='/api/professional/state',markerKey='neuro-cloud-state-v1';let revision=null,ready=false,blocked=false,lastSaved='',lastConfirmedAt=null,queue=Promise.resolve(),timer;
function status(message){let el=document.getElementById('lastAutoSave');if(!el){el=document.getElementById('neuroCloudSaveStatus');if(!el){el=document.createElement('p');el.id='neuroCloudSaveStatus';el.setAttribute('role','status');(document.querySelector('.sidebar-foot')||document.body).append(el)}}el.textContent=message}
function savedLabel(value){if(!value)return '';const saved=new Date(value);if(Number.isNaN(saved.getTime()))return '';const now=new Date(),sameDay=saved.getFullYear()===now.getFullYear()&&saved.getMonth()===now.getMonth()&&saved.getDate()===now.getDate();return new Intl.DateTimeFormat('pt-BR',sameDay?{hour:'2-digit',minute:'2-digit',second:'2-digit'}:{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(saved)}
function confirmedStatus(prefix='Salvo no servidor · Último salvamento: '){const label=savedLabel(lastConfirmedAt);status(label?prefix+label:'Salvo no servidor')}
async function fingerprint(state){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(state)));return Array.from(new Uint8Array(bytes)).map(b=>b.toString(16).padStart(2,'0')).join('')}
async function request(options){const response=await fetch(endpoint,{cache:'no-store',signal:AbortSignal.timeout(45000),...options});const data=await response.json();if(!response.ok){const error=new Error(data.error||'Não foi possível salvar no servidor.');error.status=response.status;throw error}return data}
async function upload(state){let candidate=structuredClone(state),data;try{data=await request({method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision,state:candidate})})}catch(error){if(error.status!==409)throw error;status('Conciliando alterações salvas em outra janela…');const remote=await request({});candidate=merge(remote.state||{},candidate);revision=remote.revision;data=await request({method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision,state:candidate})});if(typeof db!=='undefined'&&db&&typeof db==='object'){for(const key of Object.keys(db))delete db[key];Object.assign(db,structuredClone(candidate));try{await idbPut(db)}catch(_){}}}if(!data.ok||!data.revision||!data.savedAt)throw new Error('Servidor não confirmou a gravação.');revision=data.revision;lastConfirmedAt=data.savedAt;lastSaved=JSON.stringify(candidate);blocked=false;if(ready){try{localStorage.setItem(markerKey,JSON.stringify({revision,hash:await fingerprint(candidate),savedAt:lastConfirmedAt}))}catch{}}confirmedStatus();return data}
async function hydrate(local,fallback){status('Recuperando pacientes e verificando salvamento…');try{const remote=await request({});revision=remote.revision;lastConfirmedAt=remote.savedAt||null;let marker=null;try{marker=JSON.parse(localStorage.getItem(markerKey)||'null')}catch{}
 let state;
 try{state=choose(local,remote.state,revision,marker,local?await fingerprint(local):'')}
 catch(error){
  // A divergência é esperada após uso offline, outra aba ou uma publicação. Nunca
  // bloqueie a base: preserve os dois lados e grave uma nova revisão conciliada.
  if(!local||!remote.state)throw error;
  status('Conciliando a cópia local com o servidor…');
  state=merge(remote.state,local);
 }
 if(!state)state=remote.recovery||fallback;
 if(!state||!Array.isArray(state.patients))throw new Error('Não foi localizada uma base clínica válida.');
 // Archive the intact local base before applying the explicitly requested recovery.
 if(!remote.state&&local)await upload(local);
 const recovered=remote.recovery?recover(state,remote.recovery):structuredClone(state);
 if(!remote.state||JSON.stringify(recovered)!==JSON.stringify(remote.state))await upload(recovered);else{lastSaved=JSON.stringify(recovered)}
 return recovered;
 }catch(error){blocked=false;status('Erro ao sincronizar com o servidor: '+error.message);throw error}}
function save(localSave,getState){const task=async()=>{try{const local=await localSave();if(!local?.ok)throw new Error('A cópia local não confirmou o salvamento.');if(!ready){status('Salvo localmente — aguardando confirmação do servidor…');return {ok:true,primary:'Local',pendingCloud:true,local}}status('Salvando…');const state=structuredClone(await getState());if(JSON.stringify(state)!==lastSaved)await upload(state);else confirmedStatus();return {ok:true,primary:'Servidor',local}}catch(error){const label=savedLabel(lastConfirmedAt);status('Não salvo no servidor'+(label?' · Último salvamento confirmado: '+label:'')+': '+error.message);return {ok:false,error,stage:'CLOUD'}}};const pending=queue.then(task,task);queue=pending.then(()=>undefined,()=>undefined);return pending}
function dirty(){return ready&&typeof db!=='undefined'&&JSON.stringify(db)!==lastSaved}
function schedule(){clearTimeout(timer);timer=setTimeout(()=>{if(dirty()&&typeof persist==='function')persist()},1000)}
document.addEventListener('input',schedule);document.addEventListener('change',schedule);
setInterval(()=>{if(dirty()&&!blocked&&typeof persist==='function')persist()},5000);
window.addEventListener('beforeunload',event=>{if(dirty()){event.preventDefault();event.returnValue=''}});
async function confirmHydration(saved,expected){if(JSON.stringify(saved)!==JSON.stringify(expected)){blocked=true;throw new Error('A cópia local não confirmou a recuperação. A versão do servidor foi preservada.')}try{localStorage.setItem(markerKey,JSON.stringify({revision,hash:await fingerprint(saved),savedAt:lastConfirmedAt}))}catch{}ready=true;confirmedStatus()}
window.neuroCloud={hydrate,save,confirmHydration};
})();</script>`;
export function attachCloudPersistence(html: string) {
  const clean = html.replace(
    /<script\s+data-neuro-cloud-persistence[^>]*>[\s\S]*?<\/script>/g,
    "",
  );
  // Exported HTML may already carry the wrapper; always reinstall a single copy.
  let patched = clean
    .replace("async function persistLocal(){", "async function persist(){")
    .replace(
      "async function persist(){return window.neuroCloud.save(()=>persistLocal(),()=>idbGet())}\n",
      "",
    );
  patched = patched
    .replace(
      "idbState=await window.neuroCloud.hydrate(await idbGet(),db);await idbPut(idbState);await window.neuroCloud.confirmHydration(await idbGet(),idbState);",
      "idbState=await idbGet();",
    )
    .replace(
      "idbState=await window.neuroCloud.hydrate(await idbGet(),db);await idbPut(idbState);",
      "idbState=await idbGet();",
    );
  if (
    !patched.includes("async function persist(){") ||
    !patched.includes("idbState=await idbGet();")
  )
    throw new Error(
      "Persistência do HTML não reconhecida. Fonte preservada sem alteração.",
    );
  patched = patched.replace(
    "async function persist(){",
    "async function persist(){return window.neuroCloud.save(()=>persistLocal(),()=>idbGet())}\nasync function persistLocal(){",
  );
  patched = patched.replace(
    "idbState=await idbGet();",
    "idbState=await window.neuroCloud.hydrate(await idbGet(),db);await idbPut(idbState);await window.neuroCloud.confirmHydration(await idbGet(),idbState);",
  );
  return patched.replace(
    /<head\b[^>]*>/i,
    (head) => head + neuroCloudPersistence,
  );
}
