export type PixelSource={data:Uint8ClampedArray;width:number;height:number};
export type SpatialPoint={x:number;y:number};
const bounds:Record<string,[number,number,number,number]>={
 'practice:ac15-09':[175,825,350,555],
 'material:ad-02':[35,965,35,970],'material:as-04':[145,875,27,976],'material:tealt-08':[45,955,55,965],
 'material:ac15-10':[55,945,105,965],'material:ac15-11':[55,945,105,965],'material:ac15-12':[55,945,105,965],
 'material:tadim2-06':[35,965,45,955],
 'material:bpa-2':[40,960,80,960],'material:bpa-4':[40,960,80,960],'material:bpa-6':[40,960,80,960],
};
const horizontal=new Set(['material:ad-02','material:as-04','material:tealt-08']);
export function sourcePoint(key:string,x:number,y:number,width:number,height:number){
 if(horizontal.has(key))return {x:(1000-y)/1000*width,y:(1.5*x)/1500*height};
 return {x:x/1000*width,y:y/1000*height};
}
export function validStimulusPoint(key:string,x:number,y:number,pixels:PixelSource,tolerance=13){
 const box=bounds[key];if(!box||x<box[0]||x>box[1]||y<box[2]||y>box[3])return false;
 const p=sourcePoint(key,x,y,pixels.width,pixels.height),rx=Math.max(2,Math.round(tolerance/1000*pixels.width)),ry=Math.max(2,Math.round(tolerance/1000*pixels.height));
 for(let py=Math.max(0,Math.floor(p.y-ry));py<=Math.min(pixels.height-1,Math.ceil(p.y+ry));py+=2)for(let px=Math.max(0,Math.floor(p.x-rx));px<=Math.min(pixels.width-1,Math.ceil(p.x+rx));px+=2){const i=(py*pixels.width+px)*4,a=pixels.data[i+3],l=(pixels.data[i]+pixels.data[i+1]+pixels.data[i+2])/3;if(a>40&&l<218)return true}
 return false;
}
function distance(a:SpatialPoint,b:SpatialPoint){return Math.hypot(b.x-a.x,b.y-a.y)}
export function validAttentionStroke(key:string,stroke:SpatialPoint[],pixels:PixelSource){
 if(stroke.length<2)return false;
 const xs=stroke.map(p=>p.x),ys=stroke.map(p=>p.y),width=Math.max(...xs)-Math.min(...xs),height=Math.max(...ys)-Math.min(...ys);
 let length=0,valid=0;for(let i=0;i<stroke.length;i++){if(validStimulusPoint(key,stroke[i].x,stroke[i].y,pixels,key.startsWith('practice:ac15-')||key.startsWith('material:ac15-')?19:13))valid++;if(i)length+=distance(stroke[i-1],stroke[i])}
 const ratio=valid/stroke.length,direct=distance(stroke[0],stroke[stroke.length-1]);
 if(key.startsWith('practice:ac15-')||key.startsWith('material:ac15-'))return length>=4&&length<=250&&width<=200&&height<=58&&width>=height*.8&&ratio>=.55&&direct/length>=.32;
 return length<=185&&width<=145&&height<=145&&ratio>=.6&&direct/Math.max(length,1)>=.25;
}
