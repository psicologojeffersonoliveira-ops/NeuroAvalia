import type { PfisterColorFamily } from "./pfister-colors.ts";

export const PFISTER_NORMS_SOURCE = {
  title: "As Pirâmides Coloridas de Pfister",
  authority: "manual anexado pelo profissional",
  table4: "Estatística descritiva para frequência de cores em porcentagem",
  table5: "Estatística descritiva para síndromes cromáticas",
  table6: "Frequência das cores para os grupos normativos de 2003 e 1978",
} as const;

export type PfisterStatistic = {
  mean: number;
  sd: number;
  min: number;
  max: number;
  p25: number;
  median: number;
  p75: number;
  n: number;
};

const s = (
  mean: number,
  sd: number,
  min: number,
  max: number,
  p25: number,
  median: number,
  p75: number,
  n: number,
): PfisterStatistic => ({ mean, sd, min, max, p25, median, p75, n });

// Tabela 4, páginas impressas 160–163. Valores conferidos visualmente.
export const PFISTER_COLOR_NORMS = {
  nonPatients: {
    Az: s(18.1, 9.0, 0, 55.6, 13.3, 17.8, 22.2, 111),
    Vm: s(13.6, 7.3, 0, 40.0, 11.1, 13.3, 17.8, 111),
    Vd: s(19.7, 9.8, 0, 66.7, 13.3, 17.8, 24.4, 111),
    Vi: s(8.5, 7.5, 0, 60.0, 2.3, 8.9, 13.3, 111),
    La: s(10.8, 6.4, 0, 31.1, 6.7, 8.9, 13.3, 111),
    Am: s(9.5, 6.1, 0, 33.3, 6.7, 8.9, 11.1, 111),
    Ma: s(4.0, 5.0, 0, 33.3, 0, 2.2, 6.7, 111),
    Pr: s(4.5, 6.4, 0, 35.6, 0, 2.2, 6.7, 111),
    Br: s(8.3, 7.1, 0, 33.3, 2.2, 6.7, 13.3, 111),
    Ci: s(2.9, 3.1, 0, 11.1, 0, 2.2, 4.4, 111),
  },
} as const satisfies Record<
  string,
  Record<PfisterColorFamily, PfisterStatistic>
>;

export type PfisterSyndrome =
  | "normality"
  | "stimulus"
  | "cold"
  | "colorless"
  | "dynamism";

// Tabela 5, páginas impressas 164–167. Valores conferidos visualmente.
export const PFISTER_SYNDROME_NORMS = {
  nonPatients: {
    normality: s(51.3, 12.4, 15.6, 100.0, 44.4, 51.1, 57.8, 111),
    stimulus: s(33.9, 10.8, 0, 73.3, 28.9, 33.3, 37.8, 111),
    cold: s(46.3, 12.6, 15.6, 100.0, 40.0, 46.7, 53.3, 111),
    colorless: s(15.8, 10.0, 0, 48.9, 8.9, 15.6, 20.0, 111),
    dynamism: s(33.2, 10.8, 2.2, 66.7, 26.7, 33.3, 37.8, 111),
  },
} as const satisfies Record<
  string,
  Record<PfisterSyndrome, PfisterStatistic>
>;

// Tabela 6, página impressa 168.
export const PFISTER_HISTORICAL_COLOR_FREQUENCIES = {
  2003: {
    Az: 17.9,
    Vm: 13.5,
    Vd: 19.7,
    Vi: 8.4,
    La: 10.7,
    Am: 9.5,
    Ma: 4.1,
    Pr: 4.6,
    Br: 8.2,
    Ci: 2.8,
  },
  1978: {
    Az: 17.9,
    Vm: 15.5,
    Vd: 18.7,
    Vi: 6.5,
    La: 8.6,
    Am: 11.0,
    Ma: 7.3,
    Pr: 5.0,
    Br: 5.0,
    Ci: 2.5,
  },
} as const satisfies Record<number, Record<PfisterColorFamily, number>>;

export type PfisterNormClassification = "Diminuído" | "Na média" | "Aumentado";

export function classifyPfisterNorm(
  value: number,
  norm: PfisterStatistic,
): PfisterNormClassification {
  if (value < norm.p25) return "Diminuído";
  if (value > norm.p75) return "Aumentado";
  return "Na média";
}
