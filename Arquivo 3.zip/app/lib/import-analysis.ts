export type ImportKind = "html" | "json";

const EXPECTED_CURRENT = { patients: 20, evaluations: 20, appointments: 164, batteryRecords: 263, testRecords: 187, distinctTests: 66 };

function unique(values: string[]) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b)).slice(0, 500);
}

function captures(text: string, expression: RegExp, group = 1) {
  return unique([...text.matchAll(expression)].map(match => (match[group] || "").trim()));
}

function firstArray(root: Record<string, unknown>, keys: string[]) {
  for (const key of keys) if (Array.isArray(root[key])) return root[key] as unknown[];
  return [];
}

export function analyzeHtml(text: string, currentText: string) {
  const functions = unique([
    ...captures(text, /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g),
    ...captures(text, /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/g),
  ]);
  const currentFunctions = new Set(unique([
    ...captures(currentText, /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g),
    ...captures(currentText, /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/g),
  ]));
  const ids = captures(text, /\bid\s*=\s*["']([^"']+)["']/gi);
  const currentIds = new Set(captures(currentText, /\bid\s*=\s*["']([^"']+)["']/gi));
  const tests = unique([
    ...captures(text, /\b(?:testName|instrumentName|nomeTeste|nomeInstrumento)\s*[:=]\s*["'`]([^"'`]{2,100})["'`]/gi),
    ...captures(text, /data-(?:test|instrument)(?:-name)?\s*=\s*["']([^"']+)["']/gi),
  ]);
  const currentTests = new Set(unique([
    ...captures(currentText, /\b(?:testName|instrumentName|nomeTeste|nomeInstrumento)\s*[:=]\s*["'`]([^"'`]{2,100})["'`]/gi),
    ...captures(currentText, /data-(?:test|instrument)(?:-name)?\s*=\s*["']([^"']+)["']/gi),
  ]));
  const listeners = captures(text, /\.addEventListener\s*\(\s*["']([^"']+)["']/g);
  const scripts = (text.match(/<script\b/gi) || []).length;
  const styles = (text.match(/<style\b/gi) || []).length + (text.match(/<link\b[^>]*rel\s*=\s*["']stylesheet["']/gi) || []).length;
  const importedFunctionSet = new Set(functions);
  const importedIdSet = new Set(ids);
  const conflicts = [
    ...functions.filter(name => currentFunctions.has(name)).map(name => `Função: ${name}`),
    ...ids.filter(id => currentIds.has(id)).map(id => `ID DOM: ${id}`),
  ].slice(0, 500);
  return {
    safety: { scriptsExecuted: false, mergeEnabled: false, clinicalDataTouched: false },
    structures: {
      htmlElements: (text.match(/<[a-z][^>]*>/gi) || []).length,
      styleResources: styles,
      scriptBlocks: scripts,
      functions,
      constants: captures(text, /\bconst\s+([A-Za-z_$][\w$]*)\s*=/g),
      objects: captures(text, /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\{/g),
      tables: (text.match(/<table\b/gi) || []).length,
      listeners,
      ids,
      tests,
      subtests: captures(text, /\b(?:subtestName|nomeSubteste)\s*[:=]\s*["'`]([^"'`]+)["'`]/gi),
      instructionMarkers: (text.match(/instru[cç][aã]o|comando/gi) || []).length,
      correctionMarkers: (text.match(/corrig|score|escore|pontua/gi) || []).length,
      normativeMarkers: (text.match(/normativ|percentil|convers[aã]o/gi) || []).length,
      chartMarkers: (text.match(/chart|gr[aá]fico|canvas/gi) || []).length,
      reportMarkers: (text.match(/laudo|relat[oó]rio/gi) || []).length,
      persistenceMarkers: (text.match(/indexedDB|localStorage|sessionStorage|persist/gi) || []).length,
    },
    comparison: {
      functionsAlreadyPresent: functions.filter(name => currentFunctions.has(name)),
      functionsMissingCurrent: functions.filter(name => !currentFunctions.has(name)),
      testsAlreadyPresent: tests.filter(name => currentTests.has(name)),
      testsMissingCurrent: tests.filter(name => !currentTests.has(name)),
      importedFunctionsNotInCurrent: [...importedFunctionSet].filter(name => !currentFunctions.has(name)).length,
      importedIdsNotInCurrent: [...importedIdSet].filter(id => !currentIds.has(id)).length,
      conflicts,
      overwriteRisk: conflicts.length ? "ALTO — existem nomes/IDs coincidentes; incorporação automática bloqueada." : "NÃO DETERMINADO — revisão manual continua obrigatória.",
    },
  };
}

export function analyzeJson(text: string) {
  const parsed = JSON.parse(text) as Record<string, unknown>;
  const root = parsed.db && typeof parsed.db === "object" && !Array.isArray(parsed.db) ? parsed.db as Record<string, unknown> : parsed;
  const patients = firstArray(root, ["patients", "pacientes"]);
  const evaluations = firstArray(root, ["evaluations", "avaliacoes"]);
  const appointments = firstArray(root, ["appointments", "agenda", "compromissos"]);
  const patientRows = patients.filter(item => item && typeof item === "object") as Record<string, unknown>[];
  const batteryRecords = patientRows.reduce((sum, row) => sum + (Array.isArray(row.battery) ? row.battery.length : Array.isArray(row.bateria) ? row.bateria.length : 0), 0);
  const testObjects = patientRows.map(row => row.tests || row.testes || {}).filter(value => value && typeof value === "object" && !Array.isArray(value)) as Record<string, unknown>[];
  const testRecords = testObjects.reduce((sum, rows) => sum + Object.keys(rows).length, 0);
  const batteryNames = patientRows.flatMap(row => (Array.isArray(row.battery) ? row.battery : Array.isArray(row.bateria) ? row.bateria : [])).map(item => item && typeof item === "object" ? String((item as Record<string, unknown>).name || (item as Record<string, unknown>).nome || "") : "");
  const distinctTests = unique([...testObjects.flatMap(rows => Object.keys(rows)), ...batteryNames]).length;
  const duplicateIds: string[] = [];
  for (const [label, rows] of [["paciente", patients], ["avaliação", evaluations], ["compromisso", appointments]] as const) {
    const seen = new Set<string>();
    for (const item of rows) {
      if (!item || typeof item !== "object") continue;
      const row = item as Record<string, unknown>;
      const id = String(row.id || row.patientId || row.evaluationId || row.appointmentId || "");
      if (id && seen.has(id)) duplicateIds.push(`${label}: ${id}`);
      if (id) seen.add(id);
    }
  }
  const found = { patients: patients.length, evaluations: evaluations.length, appointments: appointments.length, batteryRecords, testRecords, distinctTests };
  const differences = Object.entries(EXPECTED_CURRENT).filter(([key, count]) => found[key as keyof typeof found] !== count).map(([key, count]) => ({ field: key, currentProtectedCount: count, importedCount: found[key as keyof typeof found] }));
  return {
    safety: { restoreExecuted: false, currentDatabaseTouched: false, mergeEnabled: false },
    found,
    currentProtectedReference: EXPECTED_CURRENT,
    comparison: {
      matchesProtectedCounts: differences.length === 0,
      differences,
      duplicateIds,
      conflicts: duplicateIds.length,
      newRecords: "Não calculado sem autorização de restauração e sem leitura destrutiva da base ativa.",
      existingRecords: "Contagens comparadas; IDs clínicos não são expostos no histórico.",
    },
    topLevelKeys: Object.keys(parsed).sort(),
    dataKeys: Object.keys(root).sort(),
  };
}
