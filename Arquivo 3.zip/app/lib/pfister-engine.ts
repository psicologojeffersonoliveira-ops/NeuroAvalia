import {
  PFISTER_COLOR_BY_CODE,
  PFISTER_COLOR_FAMILIES,
  isPfisterColor,
  type PfisterColorCode,
  type PfisterColorFamily,
} from "./pfister-colors.ts";
import {
  PFISTER_COLOR_NORMS,
  PFISTER_SYNDROME_NORMS,
  classifyPfisterNorm,
} from "./pfister-norms.ts";

export const PFISTER_ENGINE_VERSION = "1.0.0";
export const PFISTER_TEST_ID = "Pfister";
export const PFISTER_INQUIRY_KEYS = ["mostBeautiful","leastBeautiful","favoriteGeneral","leastGeneral","favoriteMaterial","leastMaterial","closing"] as const;
export const PFISTER_POSITIONS = [
  "1a",
  "2a",
  "2b",
  "3a",
  "3b",
  "3c",
  "4a",
  "4b",
  "4c",
  "4d",
  "5a",
  "5b",
  "5c",
  "5d",
  "5E",
] as const;
export type PfisterPosition = (typeof PFISTER_POSITIONS)[number];
export type PfisterPyramid = 1 | 2 | 3;

export type PfisterPlacement = {
  eventId: string;
  sequence: number;
  pyramid: PfisterPyramid;
  position: PfisterPosition;
  color: PfisterColorCode;
  recordedAt: number;
};

export type PfisterProtocol = {
  schemaVersion: 1;
  patientId: string;
  evaluationId: string;
  applicationId: string;
  testId: "Pfister";
  placements: PfisterPlacement[];
  startedAt: number;
  completedAt?: number;
  inquiry?: Record<string, string>;
  observations?: string;
};

export type PfisterPyramidResult = {
  pyramid: PfisterPyramid;
  final: Record<PfisterPosition, PfisterColorCode | null>;
  placementCount: number;
  swapCount: number;
  complete: boolean;
  colorVariation: number;
  shadeVariation: number;
};

const positionSet = new Set<string>(PFISTER_POSITIONS);

function blankPyramid(): Record<PfisterPosition, PfisterColorCode | null> {
  return Object.fromEntries(PFISTER_POSITIONS.map((p) => [p, null])) as Record<
    PfisterPosition,
    PfisterColorCode | null
  >;
}

export function assertPfisterIdentity(protocol: PfisterProtocol) {
  if (
    !protocol.patientId ||
    !protocol.evaluationId ||
    !protocol.applicationId ||
    protocol.testId !== PFISTER_TEST_ID
  )
    throw new Error("Identidade 1-1-1 incompleta para o Pfister.");
}

export function validatePfisterProtocol(protocol: PfisterProtocol) {
  assertPfisterIdentity(protocol);
  const ids = new Set<string>();
  let previous = 0;
  for (const event of protocol.placements) {
    if (
      ![1, 2, 3].includes(event.pyramid) ||
      !positionSet.has(event.position) ||
      !isPfisterColor(event.color) ||
      !event.eventId ||
      ids.has(event.eventId) ||
      !Number.isInteger(event.sequence) ||
      event.sequence <= previous
    )
      throw new Error("Histórico de colocação inválido para o Pfister.");
    ids.add(event.eventId);
    previous = event.sequence;
  }
  return protocol;
}

export function reconstructPyramid(
  protocol: PfisterProtocol,
  pyramid: PfisterPyramid,
): PfisterPyramidResult {
  validatePfisterProtocol(protocol);
  const events = protocol.placements.filter((x) => x.pyramid === pyramid),
    final = blankPyramid(),
    occupied = new Set<PfisterPosition>();
  let swaps = 0;
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index];
    if (!occupied.has(event.position)) {
      final[event.position] = event.color;
      occupied.add(event.position);
    }
  }
  const seen = new Set<PfisterPosition>();
  for (const event of events) {
    if (seen.has(event.position)) swaps += 1;
    seen.add(event.position);
  }
  const colors = Object.values(final).filter(isPfisterColor),
    families = new Set(colors.map((code) => PFISTER_COLOR_BY_CODE[code].family));
  return {
    pyramid,
    final,
    placementCount: events.length,
    swapCount: swaps,
    complete: occupied.size === PFISTER_POSITIONS.length,
    colorVariation: families.size,
    shadeVariation: new Set(colors).size,
  };
}

function countFamilies(pyramids: PfisterPyramidResult[]) {
  const counts = Object.fromEntries(
    PFISTER_COLOR_FAMILIES.map((family) => [family, 0]),
  ) as Record<PfisterColorFamily, number>;
  for (const pyramid of pyramids)
    for (const code of Object.values(pyramid.final))
      if (code) counts[PFISTER_COLOR_BY_CODE[code].family] += 1;
  return counts;
}

export function calculatePfister(protocol: PfisterProtocol) {
  const pyramids = ([1, 2, 3] as const).map((p) =>
      reconstructPyramid(protocol, p),
    ),
    counts = countFamilies(pyramids),
    total = Object.values(counts).reduce((sum, value) => sum + value, 0),
    percentages = Object.fromEntries(
      PFISTER_COLOR_FAMILIES.map((family) => [
        family,
        total ? Number(((counts[family] / total) * 100).toFixed(2)) : 0,
      ]),
    ) as Record<PfisterColorFamily, number>,
    presence = new Map<PfisterColorFamily, number>();
  for (const family of PFISTER_COLOR_FAMILIES) {
    presence.set(
      family,
      pyramids.filter((p) =>
        Object.values(p.final).some(
          (code) => code && PFISTER_COLOR_BY_CODE[code].family === family,
        ),
      ).length,
    );
  }
  const formula = {
    CA: [...presence.values()].filter((x) => x === 3).length,
    CR: [...presence.values()].filter((x) => x === 2).length,
    V: [...presence.values()].filter((x) => x === 1).length,
    AUS: [...presence.values()].filter((x) => x === 0).length,
  },
    syndromes = {
      normality: percentages.Az + percentages.Vm + percentages.Vd,
      stimulus: percentages.Vm + percentages.La + percentages.Am,
      cold: percentages.Az + percentages.Vd + percentages.Vi,
      colorless: percentages.Pr + percentages.Br + percentages.Ci,
      dynamism: percentages.Vd + percentages.Am + percentages.Ma,
    },
    colorNorms = Object.fromEntries(
      PFISTER_COLOR_FAMILIES.map((family) => {
        const norm = PFISTER_COLOR_NORMS.nonPatients[family];
        return [family, { ...norm, classification: classifyPfisterNorm(percentages[family], norm) }];
      }),
    ),
    syndromeNorms = Object.fromEntries(
      Object.entries(PFISTER_SYNDROME_NORMS.nonPatients).map(([name, norm]) => [
        name,
        { ...norm, classification: classifyPfisterNorm(syndromes[name as keyof typeof syndromes], norm) },
      ]),
    );
  const interpretation = buildPfisterInterpretation(protocol, pyramids, percentages, syndromes, formula);
  return {
    engine: PFISTER_ENGINE_VERSION,
    identity: {
      patientId: protocol.patientId,
      evaluationId: protocol.evaluationId,
      applicationId: protocol.applicationId,
      testId: protocol.testId,
    },
    pyramids,
    total,
    counts,
    percentages,
    syndromes,
    norms: { group: "nonPatients", colors: colorNorms, syndromes: syndromeNorms },
    formula: { ...formula, display: `${formula.CA}:${formula.CR}:${formula.V}:${formula.AUS}` },
    qualitative: interpretation,
    interpretation: interpretation.synthesis,
    complete: pyramids.every((p) => p.complete),
  };
}

function buildPfisterInterpretation(
  protocol: PfisterProtocol,
  pyramids: PfisterPyramidResult[],
  percentages: Record<PfisterColorFamily, number>,
  syndromes: { normality: number; stimulus: number; cold: number; colorless: number; dynamism: number },
  formula: { CA: number; CR: number; V: number; AUS: number },
) {
  const names: Record<PfisterColorFamily, string> = { Az: "azul", Vm: "vermelho", Vd: "verde", Vi: "violeta", La: "laranja", Am: "amarelo", Ma: "marrom", Pr: "preto", Br: "branco", Ci: "cinza" };
  const highest = Object.entries(percentages).sort((a, b) => b[1] - a[1]).slice(0, 3).filter(([, value]) => value > 0).map(([family, value]) => `${names[family as PfisterColorFamily]} (${value.toFixed(2)}%)`);
  const formal = pyramids.map((pyramid) => pyramid.colorVariation <= 2 ? "formação cromática concentrada" : pyramid.colorVariation >= 5 ? "formação cromática diversificada" : "formação cromática intermediária");
  const firstByPyramid = ([1, 2, 3] as const).map(p => protocol.placements.find(event => event.pyramid === p)?.color ?? null).filter(Boolean).map(code => names[PFISTER_COLOR_BY_CODE[code as PfisterColorCode].family]);
  const uniqueFirst = [...new Set(firstByPyramid)];
  const process = protocol.placements.length === 45 && pyramids.every(p => p.swapCount === 0) ? "processo sem trocas registradas e com preenchimento completo" : `${protocol.placements.length} colocações registradas, com ${pyramids.reduce((sum, p) => sum + p.swapCount, 0)} troca(s) preservada(s) no histórico`;
  const mode = uniqueFirst.length <= 1 ? "sequência inicial estável entre as pirâmides" : "sequência inicial variável entre as pirâmides";
  const inquiry = Object.values(protocol.inquiry || {}).filter(value => String(value).trim()).length;
  const synthesis = `A produção apresenta ${formal.join(", ")}. O processo foi ${process}; o modo de início foi classificado como ${mode}. No conjunto cromático, destacam-se ${highest.length ? highest.join(", ") : "nenhuma família predominante"}, com fórmula de presença CA:CR:V:AUS = ${formula.CA}:${formula.CR}:${formula.V}:${formula.AUS}. As síndromes foram consideradas pela composição de seus componentes: normalidade ${syndromes.normality.toFixed(2)}%, estímulo ${syndromes.stimulus.toFixed(2)}%, fria ${syndromes.cold.toFixed(2)}%, incolor ${syndromes.colorless.toFixed(2)}% e dinamismo ${syndromes.dynamism.toFixed(2)}%. Foram preservadas ${inquiry} resposta(s) do inquérito para integração profissional; estes indicadores não constituem diagnóstico isolado e devem ser articulados à história clínica, observação e demais instrumentos.`;
  return { formal, process, mode, firstChoices: firstByPyramid, inquiryResponseCount: inquiry, synthesis };
}

export function pfisterReportRows(result: ReturnType<typeof calculatePfister>) {
  const colorLabels: Record<PfisterColorFamily, string> = {
      Az: "Azul",
      Vm: "Vermelho",
      Vd: "Verde",
      Vi: "Violeta",
      La: "Laranja",
      Am: "Amarelo",
      Ma: "Marrom",
      Pr: "Preto",
      Br: "Branco",
      Ci: "Cinza",
    },
    syndromeLabels = {
      normality: "Síndrome de normalidade",
      stimulus: "Síndrome de estímulo",
      cold: "Síndrome fria",
      colorless: "Síndrome incolor",
      dynamism: "Síndrome de dinamismo",
    } as const;
  return [
    ...PFISTER_COLOR_FAMILIES.map((family) => ({
      test: PFISTER_TEST_ID,
      measure: `Frequência cromática — ${colorLabels[family]}`,
      result: `${result.percentages[family].toFixed(2)}%`,
      norm: `Média ${result.norms.colors[family].mean.toFixed(1)}%`,
      percentile: `P25 ${result.norms.colors[family].p25.toFixed(1)} · P75 ${result.norms.colors[family].p75.toFixed(1)}`,
      classification: result.norms.colors[family].classification,
      interpretation: "",
    })),
    ...Object.entries(syndromeLabels).map(([key, label]) => {
      const syndrome = key as keyof typeof result.syndromes,
        norm = result.norms.syndromes[syndrome];
      return {
        test: PFISTER_TEST_ID,
        measure: label,
        result: `${result.syndromes[syndrome].toFixed(2)}%`,
        norm: `Média ${norm.mean.toFixed(1)}%`,
        percentile: `P25 ${norm.p25.toFixed(1)} · P75 ${norm.p75.toFixed(1)}`,
        classification: norm.classification,
        interpretation: "",
      };
    }),
    {
      test: PFISTER_TEST_ID,
      measure: "Fórmula cromática — CA:CR:V:AUS",
      result: result.formula.display,
      norm: "Amplitude e constância cromática",
      percentile: "—",
      classification: "Resultado descritivo",
      interpretation: result.interpretation,
    },
  ];
}

export function isPfisterProtocolComplete(protocol: PfisterProtocol) {
  try {
    return calculatePfister(protocol).complete && PFISTER_INQUIRY_KEYS.every((key) => String(protocol.inquiry?.[key] || "").trim());
  } catch {
    return false;
  }
}
