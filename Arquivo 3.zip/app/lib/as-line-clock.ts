// Coordinates refer to the supplied AS sheet, displayed counterclockwise.
export function asRowAt(x:number,y:number):number|null {
  if(x<145||x>875||y<27||y>976)return null;
  return Math.max(0,Math.min(24,Math.round((y-47)/37.8)));
}
export class ASLineClock {
  row=0;
  deadline:number;
  done=false;
  constructor(now:number){this.deadline=now+15000}
  mark(row:number,now:number){
    if(this.done||now>=this.deadline||row<this.row||row>this.row+1)return false;
    if(row===this.row+1){this.row=row;this.deadline=now+15000}
    return true;
  }
  tick(now:number){
    if(this.done||now<this.deadline)return false;
    if(this.row===24){this.done=true;return true}
    this.row++;this.deadline=now+15000;return true;
  }
  remaining(now:number){return this.done?0:Math.max(0,Math.ceil((this.deadline-now)/1000))}
}
