import bpa from '../../protected/crivos/bpa.json';
import {attentionCrivoRuntime} from './attention-crivo';

export type AnswerKeyMark={id:string;x:number;y:number};
const numbers=(value:string)=>value.split(',').map(Number).filter(Number.isFinite);
const capture=(pattern:RegExp)=>attentionCrivoRuntime.match(pattern)?.[1]||'';

function attentionGrid(test:string):AnswerKeyMark[]{
 const escaped=test.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const parsed=attentionCrivoRuntime.match(new RegExp(`${escaped}:\\{nx:(\\d+),ny:(\\d+),box:\\[([^\\]]+)\\],targets:new Set\\('([^']*)'`));
 if(!parsed)return [];
 const nx=Number(parsed[1]),ny=Number(parsed[2]),[x0,x1,y0,y1]=numbers(parsed[3]);
 return numbers(parsed[4]).map(id=>{const ix=Math.floor(id/ny),iy=id%ny,sourceX=x0+ix/(nx-1)*(x1-x0),sourceY=y0+iy/(ny-1)*(y1-y0);return{id:String(id),x:sourceY/1080*1000,y:1000-sourceX/720*1000}});
}
function ac15():AnswerKeyMark[]{return numbers(capture(/const AC15_TARGETS=new Set\(\[([^\]]+)\]\)/)).map(item=>{const row=item>60?item-60:item;return{id:String(item),x:item>60?750:250,y:(124+(row-1)*14.32)/1080*1000}})}
function tadim2():AnswerKeyMark[]{const marks:AnswerKeyMark[]=[];for(const item of capture(/const TADIM2_CARDS=\{([^;]+)\};/).matchAll(/(\d+):\[([\d.]+),([\d.]+)\]/g))marks.push({id:item[1],x:Number(item[2])/420*1000,y:Number(item[3])/630*1000});return marks}
function bpaMarks(key:string):AnswerKeyMark[]{const sheet=(bpa as {sheets:Record<string,{cells:Array<{id:string;target:boolean;box:number[]}>}>}).sheets[key];return sheet?.cells.filter(cell=>cell.target).map(cell=>({id:cell.id,x:(cell.box[0]+cell.box[2])/2,y:(cell.box[1]+cell.box[3])/2}))||[]}

// Derived from the same imported constants used by the clinical scorer. This
// function never reads or mutates patient answers.
export function answerKeyMarks(test:string,key:string):AnswerKeyMark[]{
 if(test==='BPA')return bpaMarks(key);
 if(['AD','AS','TEALT'].includes(test))return attentionGrid(test);
 if(test==='AC-15')return ac15();
 if(test==='TADIM-2')return tadim2();
 return [];
}
