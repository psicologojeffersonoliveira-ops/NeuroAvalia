import {evaluatePipeline,validatePipelineFixture} from './pipeline-validation';
export const neuroPipelineValidation=String.raw`<script data-neuro-pipeline-validation>(function(){'use strict';
const evaluate=${evaluatePipeline.toString()},validateFixture=${validatePipelineFixture.toString()};
const source=()=>document.documentElement.dataset.neuroValidationSource||'unknown';
const runs=()=>{db.pipelineValidationRuns=db.pipelineValidationRuns||[];return db.pipelineValidationRuns};
const bridge=()=>window.neuroPipelineBridge;
async function save(){const result=await persist();if(!result?.ok)throw new Error('Gravação da validação não confirmada.');}
function download(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function reportMatches(html,expected){
 const doc=new DOMParser().parseFromString(html,'text/html');
 const norm=v=>String(v).replace(/\s+/g,' ').trim();
 const actual=[...doc.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('td')].map(td=>norm(td.textContent))).filter(r=>r.length);
 for(const cells of expected){const i=actual.findIndex(r=>JSON.stringify(r)===JSON.stringify(cells.map(norm)));if(i<0)return false;actual.splice(i,1)}return true;
}
function makePatient(name,d,domain=''){
 const id='qa_'+crypto.randomUUID(),evaluationId='eval_'+id,protocolId=evaluationId+':'+name;
 return {id,evaluationId,name:'VALIDAÇÃO FICTÍCIA — '+name,record:id,birth:d.birth,evaluation:d.evaluation,sex:d.sex||'',school:d.school||'',type:d.type||'Adulto',age:ageBetween(d.birth,d.evaluation),created:new Date().toISOString(),anamnesis:{},stages:{},tests:{[name]:{protocolId}},battery:[{name,selected:true,domain}],pipelineValidation:true};
}
async function prepare(name){
 const p=makePatient(name,{birth:'2000-01-01',evaluation:new Date().toISOString().slice(0,10)});
 db.patients.push(p);db.evaluations=db.evaluations||[];db.evaluations.push({patientId:p.id,evaluationId:p.evaluationId,objective:{}});
 await save();selectPatient(p.id);go('testes');
}
async function start(fixture){
 validateFixture(fixture);
 if(!Array.isArray(fixture.reportRows)||!fixture.reportRows.length||fixture.reportRows.some(r=>!Array.isArray(r)||!r.length||r.some(c=>typeof c!=='string')))throw new Error('Informe reportRows: células esperadas de cada linha da tabela do laudo.');
 if(!window.__NEURO_PERSISTENCE_READY__)throw new Error('Aguarde o carregamento do banco.');
 const item=bridge().inventory().find(x=>x.name===fixture.test);
 if(!item?.available)throw new Error('Abra os testes de uma bateria que contenha este instrumento para preparar o caso.');
 const spec=bridge().spec(fixture.test);
 const fields=spec.fields;
 if(Object.keys(fixture.answers).some(k=>!fields.some(f=>f.key===k))||fields.some(f=>f.required&&fixture.answers[f.key]===undefined))throw new Error('Respostas do caso não correspondem aos campos da aplicação.');
 const p=makePatient(fixture.test,fixture.demographics,item.domain),id=p.id,evaluationId=p.evaluationId,protocolId=p.tests[fixture.test].protocolId;
 const run={id:crypto.randomUUID(),patientId:id,evaluationId,protocolId,fixture:structuredClone(fixture),source:source(),createdAt:new Date().toISOString(),commandsConfirmed:false,applicationId:null,result:{status:'PENDENTE',reasons:['Aguardando envio.']}};
 db.patients.push(p);db.evaluations=db.evaluations||[];db.evaluations.push({patientId:id,evaluationId,objective:{}});runs().push(run);
 await save();selectPatient(id);go('testes');
 const app=await bridge().send(fixture.test);if(!app)throw new Error('Envio não confirmado. Caso mantido como pendente.');
 run.applicationId=app.applicationId;await save();return run;
}
async function check(run){
 if(run.source!==source())throw new Error('Versão alterada. Crie um novo caso para esta versão.');
 const p=db.patients.find(x=>String(x.id)===run.patientId);
 if(!p?.pipelineValidation)throw new Error('Paciente fictício do caso não localizado.');
 selectPatient(p.id);go('testes');await bridge().reconcile(run.applicationId);
 const response=await fetch('/api/professional/applications?applicationId='+encodeURIComponent(run.applicationId||''));
 if(!response.ok)throw new Error('Não foi possível verificar o recebimento online.');
 const applications=(await response.json()).applications||[],app=applications.find(x=>x.applicationId===run.applicationId);
 // Read back persisted state rather than accepting an in-memory import flag.
 if(current()!==p)throw new Error('Seleção alterada durante a verificação. Execute novamente.');
 const stored=await idbGet(),savedPatient=stored?.patients?.find(x=>String(x.id)===run.patientId);
 const record=savedPatient?.tests?.[run.fixture.test],receipt=savedPatient?.onlineApplications?.[run.applicationId];
 let rows=[],matches=false,error='';
 try{const copy=structuredClone(savedPatient);if(copy){rows=Object.values(reportCollectRows(copy)||{}).flat().filter(r=>r.test===run.fixture.test);const html=reportDocumentHTML(copy,copy.report||{});matches=reportMatches(html,run.fixture.reportRows)}}catch(e){error='Laudo não pôde ser gerado: '+e.message}
 run.result=evaluate(run,{source:source(),application:app,record,receipt,persisted:!!savedPatient,rows,reportMatches:matches});
 if(error)run.result.reasons.push(error);
 run.checkedAt=new Date().toISOString();run.observed={rows,raw:Object.fromEntries(Object.keys(run.fixture.raw).map(path=>[path,path.split('.').reduce((v,k)=>v==null?undefined:v[k],record)]))};
 await save();return run.result;
}
function panel(){
 document.querySelector('[data-pipeline-panel]')?.remove();
 const dialog=document.createElement('dialog');dialog.dataset.pipelinePanel='';dialog.style.cssText='width:min(1000px,90vw);max-height:85vh;overflow:auto;padding:22px;border:1px solid #ccd5cd;border-radius:12px;color:inherit;background:#fff';
 const h=document.createElement('h2');h.textContent='Validação online → profissional → correção → laudo';dialog.append(h);
 const note=document.createElement('p');note.textContent='Casos fictícios, sem alterar pacientes reais. Nenhum instrumento é aprovado sem caso esperado, aplicação concluída, bruto e classificação corretos e linhas presentes no laudo. A conferência de comandos é humana. O mecanismo não certifica normas clínicas.';dialog.append(note);
 const message=document.createElement('p');message.setAttribute('role','status');dialog.append(message);
 const action=(label,fn)=>{const b=document.createElement('button');b.type='button';b.className='btn secondary';b.textContent=label;b.onclick=async()=>{b.disabled=true;try{await fn()}catch(e){message.textContent=e.message}finally{b.disabled=false}};return b};
 const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.setAttribute('aria-label','Importar caso de validação JSON');input.onchange=async()=>{try{const f=input.files?.[0];if(!f)return;if(f.size>1700000)throw new Error('Arquivo muito grande.');await start(JSON.parse(await f.text()));dialog.close();message.textContent='Caso criado. Responda pelo link e depois clique em Verificar.';render()}catch(e){message.textContent=e.message}};dialog.append(input);
 dialog.append(action('Verificar todos os casos',async()=>{for(const run of runs()){try{await check(run)}catch(e){run.result={status:'PENDENTE',reasons:[e.message]}}}await save();render()}));
 dialog.append(action('Exportar evidências',()=>download({schema:1,source:source(),exportedAt:new Date().toISOString(),runs:runs()},'neuroavalia-validacao.json')));
 dialog.append(action('Fechar',()=>dialog.close()));
 const table=document.createElement('table');table.style.cssText='width:100%;margin-top:16px;text-align:left';dialog.append(table);
 function render(){table.replaceChildren();const head=document.createElement('tr');for(const title of ['Instrumento / caso','Estado','Evidências / ação']){const th=document.createElement('th');th.textContent=title;head.append(th)}table.append(head);
 const names=new Set([...bridge().inventory().map(x=>x.name),...runs().map(r=>r.fixture.test)]);
 for(const name of names){const cases=runs().filter(r=>r.fixture.test===name);if(!cases.length){const row=table.insertRow();row.insertCell().textContent=name;row.insertCell().textContent='NÃO TESTADO';const cell=row.insertCell();cell.textContent=bridge().inventory().find(x=>x.name===name)?.available?'Sem caso esperado.':'Instrumento não aberto / sem conteúdo disponível.';if(!bridge().inventory().find(x=>x.name===name)?.available)cell.append(action('Preparar instrumento',async()=>{await prepare(name);render()}));if(bridge().inventory().find(x=>x.name===name)?.available)cell.append(action('Modelo do caso',()=>download({test:name,source:'PREENCHER: manual, edição, página e caso conferido independentemente',demographics:{birth:'2000-01-01',evaluation:'2026-08-28',school:'',sex:''},answers:Object.fromEntries(bridge().spec(name).fields.map(f=>[f.key,f.type==='drawing'?{drawing:true,imageUrl:f.imageUrl}:null])),raw:{},rows:[],reportRows:[],applicationSpec:bridge().spec(name)},'modelo-validacao-'+name.replace(/[^a-z0-9]/gi,'-')+'.json')));continue}
 for(const run of cases){const row=table.insertRow();row.insertCell().textContent=name+' · '+run.createdAt;row.insertCell().textContent=run.source!==source()?'VERSÃO ALTERADA':run.result?.status||'PENDENTE';const cell=row.insertCell();const details=document.createElement('p');details.textContent=Object.entries(run.result?.steps||{}).map(([k,v])=>k+': '+v).join(' | ')+' '+(run.result?.reasons||[]).join(' ');cell.append(details);cell.append(action('Verificar',async()=>{await check(run);render()}));cell.append(action('Conferir comandos',async()=>{if(!run.applicationId)throw new Error('Caso ainda não enviado.');const r=await fetch('/api/professional/applications?applicationId='+encodeURIComponent(run.applicationId));if(!r.ok)throw new Error('Falha ao consultar aplicação.');const app=(await r.json()).applications?.find(a=>a.applicationId===run.applicationId);if(app?.status!=='CONCLUÍDA')throw new Error('Conclua a aplicação real antes de confirmar os comandos.');if(confirm('Você conferiu nesta aplicação real as instruções, itens, folhas, comandos de voz e tempos exigidos pelo manual?')){run.commandsConfirmed=true;run.commandsConfirmedAt=new Date().toISOString();await save();await check(run);render()}}));}}
 }
 render();document.body.append(dialog);dialog.showModal();
}
function install(){const workspace=document.getElementById('testsWorkspace');if(!workspace||workspace.querySelector('[data-pipeline-open]'))return;const button=document.createElement('button');button.type='button';button.className='btn secondary';button.dataset.pipelineOpen='';button.textContent='Validar percurso dos testes';button.onclick=panel;workspace.prepend(button)}
window.neuroPipelineValidation={start,check,panel};
const observer=new MutationObserver(install);observer.observe(document.body,{childList:true,subtree:true});install();
})();</script>`;
