// These helpers operate only on supplied agenda records, never on clinical patients.
export function unimedMonth(rows:any[],month:string,search=''){
 const query=search.trim().toLocaleLowerCase('pt-BR'),groups=new Map<string,any>();
 for(const row of rows){
  if(!['convenio','unimed'].includes(row.category)||row.commitmentType==='travel'||String(row.date||'').slice(0,7)!==month)continue;
  if(query&&!String(row.name||'').toLocaleLowerCase('pt-BR').includes(query))continue;
  const key=row.patientId?'patient:'+row.patientId:'name:'+String(row.name||'').trim().toLocaleLowerCase('pt-BR');
  const group=groups.get(key)||{key,name:row.name||'Sem nome',scheduled:0,performed:0};
  group.scheduled++;if(row.status==='realizado')group.performed++;groups.set(key,group);
 }
 return [...groups.values()].sort((a,b)=>a.name.localeCompare(b.name,'pt-BR'));
}
export function travelRecord(input:Record<string,string>){
 const required=['travelStartDate','travelStartTime','travelOutboundArrivalDate','travelOutboundArrivalTime','travelEndDate','travelEndTime','travelReturnArrivalDate','travelReturnArrivalTime','travelLocation','travelDestination'];
 if(required.some(key=>!input[key]?.trim()))throw new Error('Preencha as datas e horários de saída e chegada da ida e da volta, a origem e o destino.');
 const times=[['travelStartDate','travelStartTime'],['travelOutboundArrivalDate','travelOutboundArrivalTime'],['travelEndDate','travelEndTime'],['travelReturnArrivalDate','travelReturnArrivalTime']].map(([date,time])=>new Date(input[date]+'T'+input[time]+':00').getTime());
 if(times.some((value,index)=>!Number.isFinite(value)||(index>0&&value<=times[index-1])))throw new Error('Confira a ordem: saída da ida, chegada da ida, saída da volta e chegada da volta.');
 return {...input,commitmentType:'travel',category:'compromisso',patientId:'',date:input.travelStartDate,time:input.travelStartTime,duration:(times[3]-times[0])/60000,travelDurationMinutes:(times[3]-times[0])/60000,value:'',amountPaid:0,paymentStatus:'isento',paymentDate:''};
}
export const agendaOnline='<script data-neuro-agenda-online>const unimedMonth=('+unimedMonth.toString()+');const travelRecord=('+travelRecord.toString()+');'+String.raw`
(function(){
 'use strict';
 const get=id=>document.getElementById(id),value=id=>get(id)?.value||'';
 const fields={agendaTravelStartDate:['travelStartDate','Ida — data de saída','date'],agendaTravelStartTime:['travelStartTime','Ida — horário de saída','time'],agendaTravelOutboundArrivalDate:['travelOutboundArrivalDate','Ida — data de chegada','date'],agendaTravelOutboundArrivalTime:['travelOutboundArrivalTime','Ida — horário de chegada','time'],agendaTravelEndDate:['travelEndDate','Volta — data de saída','date'],agendaTravelEndTime:['travelEndTime','Volta — horário de saída','time'],agendaTravelReturnArrivalDate:['travelReturnArrivalDate','Volta — data de chegada','date'],agendaTravelReturnArrivalTime:['travelReturnArrivalTime','Volta — horário de chegada','time'],agendaTravelLocation:['travelLocation','Destino inicial / origem','text'],agendaTravelDestination:['travelDestination','Destino final','text']};
 function form(){
  const wrap=get('agendaTravelFields');if(!wrap)return;
  for(const [id,[,label,type]] of Object.entries(fields)){
   if(!get(id)){const field=document.createElement('div');field.className='field';const l=document.createElement('label');l.textContent=label;const input=document.createElement('input');input.id=id;input.type=type;l.htmlFor=id;field.append(l,input);wrap.append(field)}
   const input=get(id);input.closest('.field').querySelector('label').textContent=label;
   wrap.append(input.closest('.field'));input.disabled=value('agendaCommitmentType')!=='travel';input.required=!input.disabled;
  }
  const active=value('agendaCommitmentType')==='travel';
  const card=get('agendaFormCard');if(card){
   card.classList.toggle('neuro-travel-only',active);
   for(const input of card.querySelectorAll('input,select,textarea')){
    if(input.id==='agendaCommitmentType'||Object.hasOwn(fields,input.id)||input.type==='hidden')continue;
    if(active){if(!input.hasAttribute('data-travel-disabled-before'))input.dataset.travelDisabledBefore=String(input.disabled);input.disabled=true}
    else if(input.hasAttribute('data-travel-disabled-before')){input.disabled=input.dataset.travelDisabledBefore==='true';delete input.dataset.travelDisabledBefore}
   }
  }
  wrap.hidden=!active;wrap.classList.toggle('agenda-field-hidden',!active);
  for(const field of wrap.querySelectorAll('.field'))field.hidden=!field.querySelector(Object.keys(fields).map(id=>'#'+id).join(','));
 }
 const oldOpen=window.openAgendaForm,oldEdit=window.editAgendaAppointment,oldSave=window.saveAgendaAppointment,oldRender=window.renderAgenda;
 window.openAgendaForm=function(){oldOpen?.apply(this,arguments);form();for(const id of Object.keys(fields))if(get(id))get(id).value=''};
 window.editAgendaAppointment=function(id){oldEdit?.apply(this,arguments);form();const record=(db.agenda||[]).find(row=>String(row.id)===String(id));if(record)for(const [id,[key]] of Object.entries(fields))get(id).value=record[key]||''};
 window.saveAgendaAppointment=function(event){
  if(value('agendaCommitmentType')!=='travel')return oldSave?.apply(this,arguments);
  event?.preventDefault();let record;try{record=travelRecord(Object.fromEntries(Object.entries(fields).map(([id,[key]])=>[key,value(id).trim()])))}catch(error){toast(error.message);return false}
  const id=value('agendaAppointmentId'),index=id?(db.agenda||[]).findIndex(row=>String(row.id)===id):-1;
  if(id&&index<0){toast('Viagem não localizada. Nenhum compromisso foi alterado.');return false}
  const now=new Date().toISOString();record={...(index>=0?db.agenda[index]:{}),...record,id:id||'ag_'+crypto.randomUUID(),name:value('agendaName').trim()||'Viagem',notes:value('agendaNotes'),travelObservations:value('agendaTravelObservations'),status:value('agendaStatus')||'agendado',modality:value('agendaModality'),updatedAt:now};
  if(index>=0)db.agenda[index]=record;else{record.createdAt=now;(db.agenda=db.agenda||[]).push(record)}
  persist();closeAgendaForm();agendaWeekStart=agendaISO(agendaMonday(agendaDate(record.date)));window.renderAgenda();return true;
 };
 let chosenMonth='';
 function summary(){
  const host=get('agendaSummary');if(!host)return;
  const month=chosenMonth||(typeof agendaWeekStart==='string'?agendaWeekStart.slice(0,7):new Date().toISOString().slice(0,7));
  const groups=unimedMonth(db.agenda||[],month,value('agendaSearch'));
  get('neuroUnimedMonth')?.remove();const box=document.createElement('details');box.id='neuroUnimedMonth';box.className='agenda-unimed-month';box.open=window.__neuroUnimedOpen||false;
  const title=document.createElement('summary');title.textContent='Unimed · '+month.slice(5)+'/'+month.slice(0,4)+' · '+groups.reduce((sum,g)=>sum+g.performed,0)+' sessões realizadas';box.append(title);
  const label=document.createElement('label');label.textContent='Mês ';const input=document.createElement('input');input.type='month';input.value=month;input.onchange=()=>{if(!input.value)return;chosenMonth=input.value;window.__neuroUnimedOpen=true;summary()};label.append(input);box.append(label);
  for(const group of groups){
   const patient=document.createElement('details');patient.className='private-patient-folder';patient.open=window.__neuroUnimedPatient===group.key;
   const heading=document.createElement('summary'),name=document.createElement('b'),totals=document.createElement('small');name.textContent=group.name;totals.textContent=group.performed+' realizadas · '+group.scheduled+' agendadas';heading.append(name,totals);patient.append(heading);
   const body=document.createElement('div');body.className='private-patient-folder-body';
   const label=document.createElement('label');label.textContent='Sessões lançadas no mês ';const count=document.createElement('input');count.type='number';count.min='0';count.step='1';count.setAttribute('aria-label','Sessões lançadas de '+group.name);count.value=String(db.agendaUnimedLaunches?.[month]?.[group.key]??'');count.onchange=()=>{const raw=count.value;if(raw!==''&&(!Number.isInteger(Number(raw))||Number(raw)<0)){count.setCustomValidity('Informe uma quantidade inteira, igual ou maior que zero.');count.reportValidity();return}count.setCustomValidity('');db.agendaUnimedLaunches=db.agendaUnimedLaunches||{};db.agendaUnimedLaunches[month]=db.agendaUnimedLaunches[month]||{};if(raw==='')delete db.agendaUnimedLaunches[month][group.key];else db.agendaUnimedLaunches[month][group.key]=Number(raw);persist()};label.append(count);body.append(label);
   const table=document.createElement('table');table.className='agenda-balance-table';table.innerHTML='<thead><tr><th>Data</th><th>Horário</th><th>Situação</th></tr></thead>';const rows=document.createElement('tbody');
   const appointments=(db.agenda||[]).filter(row=>['convenio','unimed'].includes(row.category)&&row.commitmentType!=='travel'&&String(row.date||'').slice(0,7)===month&&(row.patientId?'patient:'+row.patientId:'name:'+String(row.name||'').trim().toLocaleLowerCase('pt-BR'))===group.key).sort((a,b)=>(a.date+' '+a.time).localeCompare(b.date+' '+b.time));
   for(const record of appointments){const row=document.createElement('tr');for(const text of [String(record.date).split('-').reverse().join('/'),record.time||'—',record.status||'agendado']){const cell=document.createElement('td');cell.textContent=text;row.append(cell)}rows.append(row)}table.append(rows);body.append(table);patient.append(body);
   patient.ontoggle=()=>{if(patient.open){window.__neuroUnimedPatient=group.key;for(const other of box.querySelectorAll('.private-patient-folder'))if(other!==patient)other.open=false}else if(window.__neuroUnimedPatient===group.key)window.__neuroUnimedPatient=null};box.append(patient);
  }
  box.ontoggle=()=>window.__neuroUnimedOpen=box.open;host.append(box);
  for(const badge of document.querySelectorAll('#agendaWeek [data-unimed-session-count]'))badge.remove();
 }
 window.renderAgenda=function(){const result=oldRender?.apply(this,arguments);summary();return result};
 document.addEventListener('change',event=>{if(event.target?.id==='agendaCommitmentType')form()});
 function start(){form();summary()}if(document.readyState==='loading')addEventListener('DOMContentLoaded',start,{once:true});else start();
})();</script><style data-neuro-agenda-online>
#agendaWeek .agenda-appointment.commitment-travel::before{content:'✈️';display:block!important;text-align:center;font-size:30px;line-height:1.2;margin:4px auto 7px;position:static;width:auto;height:auto;background:none}
#agendaFormCard.neuro-travel-only .field:not(:has(#agendaCommitmentType)):not(#agendaTravelFields):not(#agendaTravelFields .field){display:none!important}
#agendaTravelFields .field[hidden]{display:none!important}
.agenda-unimed-month{width:100%;padding:10px;border:1px solid var(--line);border-radius:8px;overflow:auto}.agenda-unimed-month summary{cursor:pointer;font-weight:700}.agenda-unimed-month input{max-width:150px}.agenda-unimed-month label{display:block;margin:8px 0}[data-unimed-session-count]{display:block;margin-top:5px}
</style>`;
