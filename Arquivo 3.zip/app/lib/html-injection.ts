export function injectBeforeClosingBody(html:string,injection:string){
  const index=html.toLowerCase().lastIndexOf("</body>");
  return index<0?html+injection:html.slice(0,index)+injection+html.slice(index);
}
