export const neuroCpfIntegration=String.raw`<script data-neuro-cpf-integration>(()=>{'use strict';
const format=value=>String(value||'').replace(/\D/g,'').slice(0,11).replace(/^(\d{3})(\d)/,'$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/,'$1.$2.$3').replace(/\.(\d{3})(\d)/,'.$1-$2');
function sync(target=document.getElementById('cpfPaciente')){if(target)target.value=format(target.value)}
document.addEventListener('input',event=>{if(event.target?.id==='cpfPaciente')sync(event.target)},true);document.addEventListener('focusin',event=>{if(event.target?.id==='cpfPaciente')sync(event.target)},true);addEventListener('DOMContentLoaded',()=>sync(),{once:true});
})();</script>`;
