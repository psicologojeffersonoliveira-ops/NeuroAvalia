export function anamnesisSemanticPhrase(label:string,input:unknown){
 const normalized=(text:string)=>String(text||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/^\d+\.\s*/,'').replace(/\?$/,'').trim().toLowerCase();
 const yes=(text:string)=>/^(sim|true|1)$/i.test(String(text).trim()),no=(text:string)=>/^(não|nao|false|0)$/i.test(String(text).trim());
 const ordinal=(text:string)=>{const raw=String(text).match(/\d+/)?.[0]||String(text).trim().toLowerCase();return ({'1':'primeiro','2':'segundo','3':'terceiro','4':'quarto','5':'quinto','6':'sexto','7':'sétimo','8':'oitavo','9':'nono','10':'décimo'} as Record<string,string>)[raw]||raw};
 const value=String(input??'').trim(),key=normalized(label);
 if(!value)return'';
 if(/consanguin/.test(key))return yes(value)?'Os pais são consanguíneos':'Os pais não são consanguíneos';
 if(/ordem.*nascimento|posicao.*filh/.test(key))return`O paciente é o ${ordinal(value)} filho`;
 if(/pre[- ]?natal/.test(key))return yes(value)?'A mãe realizou acompanhamento pré-natal':'A mãe não realizou acompanhamento pré-natal';
 if(/gesta(c|ç)ao.*planejad/.test(key))return yes(value)?'A gestação foi planejada':'A gestação não foi planejada';
 if(/sintoma|manifestac|dificuldade|queixa/.test(key)&&value.includes(','))return`Foram relatados ${value}`;
 if(/não sabe informar|nao sabe informar/i.test(value))return`Não foi possível precisar ${label.replace(/^\d+\.\s*/,'').replace(/\?$/,'').toLowerCase()}`;
 if(yes(value))return`Há relato afirmativo sobre ${label.replace(/^\d+\.\s*/,'').replace(/\?$/,'').toLowerCase()}`;
 if(no(value))return`Não houve relato de ${label.replace(/^\d+\.\s*/,'').replace(/\?$/,'').toLowerCase()}`;
 return`${label.replace(/^\d+\.\s*/,'').replace(/\?$/,'')}: ${value}`;
}
