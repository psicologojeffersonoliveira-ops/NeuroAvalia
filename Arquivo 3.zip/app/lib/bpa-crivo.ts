import mask from '../../protected/crivos/bpa.json';

type Point={x:number;y:number};
type Cell={id:string;row:number;column:number;target:boolean;box:number[]};
type Sheet={component:string;imageUrl:string;cells:Cell[]};
const BPA_CRIVO=mask as {version:number;sourceSha256:string;sheets:Record<string,Sheet>};

// Geometry only. Do not interpret unmarked targets as clinical omissions until
// the instrument's stopping/omission/autocorrection rules have been supplied.
export function recognizeBpaGeometry(key:string,value:unknown,crivo:typeof BPA_CRIVO){
 const sheet=crivo.sheets[key];
 if(!sheet)throw new Error('Crivo BPA não localizado para esta folha.');
 const drawing=typeof value==='string'?JSON.parse(value):value;
 if(!drawing||typeof drawing!=='object')throw new Error('Resposta geométrica inválida.');
 const data=drawing as {version:number;imageUrl:string;orientation?:string;strokes:Point[][]};
 if(![1,2].includes(data.version)||data.imageUrl!==sheet.imageUrl||(data.orientation&&data.orientation!=='original')||!Array.isArray(data.strokes)||data.strokes.length>10000||data.strokes.some(s=>!Array.isArray(s)||!s.length||s.some(p=>!p||!Number.isFinite(p.x)||!Number.isFinite(p.y)||p.x<0||p.x>1000||p.y<0||p.y>1000)))throw new Error('Folha ou coordenadas incompatíveis com o crivo BPA.');
 // Slab intersection checks the complete segment, including fast pen movement.
 function intersects(a:Point,b:Point,box:number[]){
  const tolerance=1.5;let low=0,high=1;
  for(const [v,d,min,max] of [[a.x,b.x-a.x,box[0]-tolerance,box[2]+tolerance],[a.y,b.y-a.y,box[1]-tolerance,box[3]+tolerance]]){
   if(d===0){if(v<min||v>max)return false;continue}
   const t1=(min-v)/d,t2=(max-v)/d;low=Math.max(low,Math.min(t1,t2));high=Math.min(high,Math.max(t1,t2));if(low>high)return false;
  }
  return true;
 }
 const marked=new Set<string>(),ambiguous:Array<{stroke:number;cells:string[]}>=[],outside:number[]=[];
 data.strokes.forEach((stroke,index)=>{
  const touched=sheet.cells.filter(cell=>stroke.some((point,i)=>intersects(point,stroke[Math.max(0,i-1)],cell.box)));
  if(touched.length===1)marked.add(touched[0].id);
  else if(touched.length>1)ambiguous.push({stroke:index,cells:touched.map(c=>c.id)});
  else outside.push(index);
 });
 const targets=sheet.cells.filter(c=>c.target),hits=targets.filter(c=>marked.has(c.id)).map(c=>c.id);
 return {maskVersion:crivo.version,sourceSha256:crivo.sourceSha256,component:sheet.component,
  markedStimuli:[...marked],hits,nonTargets:sheet.cells.filter(c=>!c.target&&marked.has(c.id)).map(c=>c.id),
  unmarkedTargets:targets.filter(c=>!marked.has(c.id)).map(c=>c.id),ambiguous,outside,
  correctionPending:true,reason:'Pendente: regra oficial de omissões, término e autocorreções; validação funcional completa.'};
}
export function recognizeBpa(key:string,value:unknown){return recognizeBpaGeometry(key,value,BPA_CRIVO)}

// This string is injected ONLY in the authenticated professional HTML. Neither
// targets nor the key PDF are exposed to the respondent or the public assets.
export const bpaCrivoRuntime='const BPA_CRIVO='+JSON.stringify(BPA_CRIVO)+';const recognizeBpa=(key,value)=>('+recognizeBpaGeometry.toString()+')(key,value,BPA_CRIVO);';
