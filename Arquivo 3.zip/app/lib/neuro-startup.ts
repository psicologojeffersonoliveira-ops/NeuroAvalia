export const neuroStartup=String.raw`<style data-neuro-online-startup>#agendaWeek .agenda-appointment.commitment-travel::before{content:'✈';display:inline-block;font-size:18px;line-height:1;margin-right:5px}</style><script data-neuro-online-startup>(function(){
'use strict';
async function resetInitialSelection(){
 await Promise.resolve(window.__NEURO_PERSISTENCE_HYDRATION__);
 if(typeof db==='undefined')throw new Error('Banco clínico não inicializado.');
 db.current=null;db.currentEvaluationId=null;
 window.__NEURO_ONLINE_STARTING__=false;
 if(typeof closeEvaluationOverlay==='function')closeEvaluationOverlay(true);
 if(typeof updateAll==='function')updateAll();
 if(typeof renderEvaluations==='function')renderEvaluations();
 // Contact fields added by the online integration are not cleared by legacy updateAll.
 for(const id of ['telefoneCelular','whatsapp','emailPaciente']){const el=document.getElementById?.(id);if(el){el.value='';el.disabled=false}}
 const same=document.getElementById?.('whatsappMesmoCelular');if(same)same.checked=false;
}
function start(){resetInitialSelection().catch(error=>console.error('[NeuroAvalia contexto inicial]',error))}
if(document.readyState==='loading')addEventListener('DOMContentLoaded',start,{once:true});else start();
})();</script>`;
