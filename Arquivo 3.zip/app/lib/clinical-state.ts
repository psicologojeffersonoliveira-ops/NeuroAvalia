export const RECOVERY_VERSION='2026-08-28-patients-v1';
export const RECOVERY_IDS=['1787427452631','1787285462940','1787146371586','1785715887122'];
export function validClinicalState(db:any){
 if(!db||!Array.isArray(db.patients)||!Array.isArray(db.evaluations)||!Array.isArray(db.agenda))return false;
 const unique=(rows:any[],key:string)=>rows.every(r=>r&&r[key]!=null&&String(r[key])!=='')&&new Set(rows.map(r=>String(r[key]))).size===rows.length;
 return unique(db.patients,'id')&&unique(db.evaluations,'evaluationId');
}
export function recoverMissingPatients(current:any,backup:any){
 const state=structuredClone(current||backup);
 if(state.neuroRecoveryVersion==='2026-08-28-patients-v1')return state;
 const ids=['1787427452631','1787285462940','1787146371586','1785715887122'];
 for(const p of backup.patients||[]){
  if(!ids.includes(String(p.id))||state.patients.some((r:any)=>String(r.id)===String(p.id)))continue;
  state.patients.push(structuredClone(p));
  for(const e of backup.evaluations||[])if(String(e.patientId)===String(p.id)&&!state.evaluations.some((r:any)=>String(r.evaluationId)===String(e.evaluationId)))state.evaluations.push(structuredClone(e));
 }
 state.neuroRecoveryVersion='2026-08-28-patients-v1';return state;
}
export function chooseClinicalState(local:any,cloud:any,revision:string|null,marker:any,localHash:string){
 if(!cloud)return local;
 if(!local)return cloud;
 if(JSON.stringify(local)===JSON.stringify(cloud))return cloud;
 if(marker?.revision===revision)return local;
 if(marker?.hash===localHash)return cloud;
 throw new Error('Há alterações diferentes neste navegador e no servidor. A sincronização foi bloqueada para preservar ambas as bases. Exporte o backup deste navegador para conferência.');
}

export function mergeClinicalState(remote:any,local:any){
 function mergeObject(a:any,b:any):any{
  if(Array.isArray(a)||Array.isArray(b))return structuredClone(b??a);
  if(!a||typeof a!=='object'||!b||typeof b!=='object')return structuredClone(b===undefined?a:b);
  const value=structuredClone(a);
  for(const [key,item] of Object.entries(b))value[key]=key in a?mergeObject(a[key],item):structuredClone(item);
  return value;
 }
 function mergeRows(a:any[],b:any[],key:(row:any)=>string){
  const value=(a||[]).map(row=>structuredClone(row)),positions=new Map(value.map((row,index)=>[key(row),index]));
  for(const row of b||[]){const id=key(row),at=positions.get(id);if(at===undefined){positions.set(id,value.length);value.push(structuredClone(row))}else value[at]=mergeObject(value[at],row)}
  return value;
 }
 const out=mergeObject(remote,local);
 out.patients=mergeRows(remote?.patients||[],local?.patients||[],p=>String(p?.id));
 out.evaluations=mergeRows(remote?.evaluations||[],local?.evaluations||[],e=>String(e?.evaluationId));
 out.agenda=mergeRows(remote?.agenda||[],local?.agenda||[],a=>String(a?.id));
 return out;
}
