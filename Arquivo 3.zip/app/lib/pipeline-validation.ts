/** Validation only: never computes clinical scores or changes normative engines. */
export function evaluatePipeline(run:any, evidence:any) {
 const steps:Record<string,string>={online:'PENDENTE',professional:'PENDENTE',correction:'PENDENTE',report:'PENDENTE',commands:'PENDENTE'};
 const reasons:string[]=[];
 const equal=(a:any,b:any):boolean=>JSON.stringify(stable(a))===JSON.stringify(stable(b));
 function stable(v:any):any {return Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v}
 const fail=(stage:string,message:string)=>{steps[stage]='FALHOU';reasons.push(message)};
 const fixture=run.fixture;
 if(!fixture||!run.applicationId)return {status:'PENDENTE',steps,reasons:['Caso ainda não enviado.']};
 if(!run.source||run.source==='unknown'||run.source!==evidence.source)return {status:'PENDENTE',steps,reasons:['Fonte do sistema mudou. Execute um novo caso nesta versão.']};
 const app=evidence.application;
 if(!app||app.status!=='CONCLUÍDA')return {status:'PENDENTE',steps,reasons:['Aguardando conclusão real da aplicação online.']};
 const identity=String(app.applicationId)===run.applicationId&&String(app.patientId)===run.patientId&&String(app.evaluationId)===run.evaluationId&&String(app.protocolId)===run.protocolId&&app.testId===fixture.test;
 if(!identity){fail('online','Aplicação, paciente, avaliação, instrumento ou protocolo divergente.');return {status:'FALHOU',steps,reasons}}
 const answersMatch=Object.keys(app.answers||{}).length===Object.keys(fixture.answers).length&&Object.entries(fixture.answers).every(([key,expected]:[string,any])=>{
  if(expected&&typeof expected==='object'&&expected.drawing===true){try{const drawing=JSON.parse(app.answers[key]);return drawing.imageUrl===expected.imageUrl&&Array.isArray(drawing.strokes)}catch{return false}}
  return equal(app.answers?.[key],expected);
 });
 if(!answersMatch)fail('online','Respostas recebidas diferem do caso previamente definido.');else steps.online='PASSOU';
 const record=evidence.record,receipt=evidence.receipt;
 if(!receipt?.imported||receipt.missingControls?.length||!evidence.persisted)reasons.push('Retorno ainda não importado e persistido integralmente.');
 else if(!record?.onlineResponse||record.onlineResponse.applicationId!==run.applicationId||record.onlineResponse.patientId!==run.patientId||record.onlineResponse.evaluationId!==run.evaluationId||record.onlineResponse.protocolId!==run.protocolId||!equal(record.onlineResponse.answers,app.answers))fail('professional','Proveniência ou respostas do profissional divergentes.');
 else steps.professional='PASSOU';
 if(steps.professional==='PASSOU'){
  if(record.remoteCorrectionPending||receipt.correctionPending)reasons.push('Correção automática pendente; material recebido não equivale a corrigido.');
  else {
   const get=(path:string)=>path.split('.').reduce((v:any,k:string)=>v==null?undefined:v[k],record);
   if(!Object.entries(fixture.raw).every(([path,value])=>equal(get(path),value)))fail('correction','Resultado bruto diverge do valor esperado.');
   else if(!equal(evidence.rows,fixture.rows))fail('correction','Cálculo, classificação ou linhas de resultado divergem do caso esperado.');
   else steps.correction='PASSOU';
  }
 }
 if(steps.correction==='PASSOU'){
  if(evidence.reportMatches===true)steps.report='PASSOU';else fail('report','As linhas esperadas não foram encontradas integralmente no documento de laudo.');
 }
 if(run.commandsConfirmed===true)steps.commands='PASSOU';else reasons.push('Comandos e interação ainda precisam de conferência humana na aplicação real.');
 return {status:Object.values(steps).includes('FALHOU')?'FALHOU':Object.values(steps).every(v=>v==='PASSOU')?'PASSOU':'PENDENTE',steps,reasons};
}
export function validatePipelineFixture(f:any){
 const object=(v:any)=>v&&typeof v==='object'&&!Array.isArray(v);
 if(!object(f)||typeof f.test!=='string'||!f.test.trim()||typeof f.source!=='string'||(!f.source.trim()||f.source.startsWith('PREENCHER')))throw new Error('Informe instrumento e referência do resultado esperado.');
 if(!object(f.demographics)||!/^\d{4}-\d{2}-\d{2}$/.test(f.demographics.birth||'')||!/^\d{4}-\d{2}-\d{2}$/.test(f.demographics.evaluation||''))throw new Error('Informe datas fictícias de nascimento e avaliação (AAAA-MM-DD).');
 if(!object(f.answers)||!Object.keys(f.answers).length||!object(f.raw)||!Object.keys(f.raw).length||!Array.isArray(f.rows)||!f.rows.length)throw new Error('O caso precisa conter respostas, bruto esperado e linhas esperadas de laudo.');
 if(Object.keys(f.raw).some(k=>!k||k.split('.').some(p=>['__proto__','prototype','constructor'].includes(p))))throw new Error('Caminho de bruto inválido.');
 if(f.rows.some((r:any)=>!object(r)||r.test!==f.test||typeof r.measure!=='string'||r.result==null||typeof r.classification!=='string'||!r.classification.trim()||r.classification==='—'))throw new Error('Cada linha precisa de instrumento, medida, resultado e classificação esperada.');
 if(!Array.isArray(f.reportRows)||f.reportRows.length!==f.rows.length||f.rows.some((row:any,i:number)=>{const cells=f.reportRows[i];return !Array.isArray(cells)||cells.some((c:any)=>typeof c!=='string')||![row.measure,String(row.result),row.classification].every(v=>cells.includes(v))}))throw new Error('reportRows deve corresponder às medidas, resultados e classificações esperadas, na mesma ordem.');
 if(JSON.stringify(f).length>1600000)throw new Error('Caso excede o limite de tamanho.');
 return f;
}
