export type Point={x:number;y:number};
export type Stroke=Point[];
export function appendPoint(strokes:Stroke[],point:Point,start=false):Stroke[]{
 if(!Number.isFinite(point.x)||!Number.isFinite(point.y))return strokes;
 const bounded={x:Math.max(0,Math.min(1000,Math.round(point.x))),y:Math.max(0,Math.min(1000,Math.round(point.y)))};
 if(start)return [...strokes,[bounded]];
 if(!strokes.length)return strokes;
 return [...strokes.slice(0,-1),[...strokes[strokes.length-1],bounded]];
}
export function validDrawing(value:unknown){
 if(typeof value!=='string')return false;
 try{const data=JSON.parse(value);return (data.version===2||data.version===1)&&Array.isArray(data.strokes)&&data.strokes.length<=10000&&data.strokes.every((stroke:unknown)=>Array.isArray(stroke)&&stroke.length>0&&stroke.every(point=>point&&typeof point.x==='number'&&typeof point.y==='number'&&Number.isFinite(point.x)&&Number.isFinite(point.y)&&point.x>=0&&point.x<=1000&&point.y>=0&&point.y<=1000))}catch{return false}
}
