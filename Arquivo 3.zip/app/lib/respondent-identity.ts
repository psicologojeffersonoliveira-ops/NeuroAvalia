export type IdentifierKind="name"|"cpf"|"birth";

export function onlyDigits(value:string){return String(value||"").replace(/\D/g,"")}

export function formatCpf(value:string){
 const d=onlyDigits(value).slice(0,11);
 return d.replace(/^(\d{3})(\d)/,"$1.$2").replace(/^(\d{3})\.(\d{3})(\d)/,"$1.$2.$3").replace(/\.(\d{3})(\d)/,".$1-$2");
}

export function formatBirth(value:string){
 const d=onlyDigits(value).slice(0,8);
 return d.length<=2?d:d.length<=4?`${d.slice(0,2)}/${d.slice(2)}`:`${d.slice(0,2)}/${d.slice(2,4)}/${d.slice(4)}`;
}

export function normalizeIdentifier(kind:IdentifierKind,value:string){
 if(kind==="cpf"){const d=onlyDigits(value);return d.length===11?d:null}
 if(kind==="birth"){
  const d=onlyDigits(value);if(d.length!==8)return null;
  const day=Number(d.slice(0,2)),month=Number(d.slice(2,4)),year=Number(d.slice(4));
  const date=new Date(Date.UTC(year,month-1,day));
  if(year<1900||year>new Date().getUTCFullYear()||date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==day)return null;
  return d;
 }
 const name=String(value||"").normalize("NFC").trim().replace(/\s+/g," ").toLocaleLowerCase("pt-BR");
 return name.length>=2?name:null;
}

export function taggedIdentifier(kind:IdentifierKind,value:string){const normalized=normalizeIdentifier(kind,value);return normalized?`${kind}:${normalized}`:null}
