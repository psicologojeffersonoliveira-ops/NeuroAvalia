export const PFISTER_COLOR_FAMILIES = [
  "Az",
  "Vm",
  "Vd",
  "Vi",
  "La",
  "Am",
  "Ma",
  "Pr",
  "Br",
  "Ci",
] as const;

export type PfisterColorFamily = (typeof PFISTER_COLOR_FAMILIES)[number];

export const PFISTER_COLORS = [
  { code: "Az1", family: "Az", label: "Azul 1", hex: "#b9d9ec" },
  { code: "Az2", family: "Az", label: "Azul 2", hex: "#3186c4" },
  { code: "Az3", family: "Az", label: "Azul 3", hex: "#174d82" },
  { code: "Az4", family: "Az", label: "Azul 4", hex: "#102d52" },
  { code: "Vm1", family: "Vm", label: "Vermelho 1", hex: "#efaaaa" },
  { code: "Vm2", family: "Vm", label: "Vermelho 2", hex: "#df3037" },
  { code: "Vm3", family: "Vm", label: "Vermelho 3", hex: "#a91f2d" },
  { code: "Vm4", family: "Vm", label: "Vermelho 4", hex: "#651f2b" },
  { code: "Vd1", family: "Vd", label: "Verde 1", hex: "#b8dca8" },
  { code: "Vd2", family: "Vd", label: "Verde 2", hex: "#51a956" },
  { code: "Vd3", family: "Vd", label: "Verde 3", hex: "#267743" },
  { code: "Vd4", family: "Vd", label: "Verde 4", hex: "#234d38" },
  { code: "Vi1", family: "Vi", label: "Violeta 1", hex: "#cbb1df" },
  { code: "Vi2", family: "Vi", label: "Violeta 2", hex: "#8e5bb2" },
  { code: "Vi3", family: "Vi", label: "Violeta 3", hex: "#513160" },
  { code: "La1", family: "La", label: "Laranja 1", hex: "#f3a24c" },
  { code: "La2", family: "La", label: "Laranja 2", hex: "#e36a26" },
  { code: "Am1", family: "Am", label: "Amarelo 1", hex: "#f7df60" },
  { code: "Am2", family: "Am", label: "Amarelo 2", hex: "#efb82e" },
  { code: "Ma1", family: "Ma", label: "Marrom 1", hex: "#a66d4c" },
  { code: "Ma2", family: "Ma", label: "Marrom 2", hex: "#654334" },
  { code: "Pr", family: "Pr", label: "Preto", hex: "#171717" },
  { code: "Br", family: "Br", label: "Branco", hex: "#fffdf5" },
  { code: "Ci", family: "Ci", label: "Cinza", hex: "#929292" },
] as const satisfies ReadonlyArray<{
  code: string;
  family: PfisterColorFamily;
  label: string;
  hex: string;
}>;

export type PfisterColorCode = (typeof PFISTER_COLORS)[number]["code"];

export const PFISTER_COLOR_BY_CODE = Object.fromEntries(
  PFISTER_COLORS.map((color) => [color.code, color]),
) as Record<PfisterColorCode, (typeof PFISTER_COLORS)[number]>;

export function isPfisterColor(value: unknown): value is PfisterColorCode {
  return typeof value === "string" && value in PFISTER_COLOR_BY_CODE;
}
