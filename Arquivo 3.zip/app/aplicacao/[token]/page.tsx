import RespondentPortal from "./respondent";
import IdentifierMask from "./identifier-mask";
export default async function ApplicationPage({params}:{params:Promise<{token:string}>}){const {token}=await params;return <><IdentifierMask/><RespondentPortal token={token}/></>}
