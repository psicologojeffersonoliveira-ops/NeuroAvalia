"use client";
import { PointerEvent, useEffect, useRef, useState } from "react";
import { appendPoint } from "../../lib/drawing-response";
import { ASLineClock, asRowAt } from "../../lib/as-line-clock";
import { validAttentionStroke } from "../../lib/attention-spatial";
import type { PixelSource } from "../../lib/attention-spatial";
import { PfisterResponse } from "./pfister-response";
import { isPfisterProtocolComplete } from "../../lib/pfister-engine";
type Option = { value: string; label: string };
type Field = {
  key: string;
  label: string;
  type:
    | "radio"
    | "checkbox"
    | "select"
    | "text"
    | "number"
    | "textarea"
    | "drawing";
  required?: boolean;
  options?: Option[];
  imageUrl?: string;
};
type Stage = {
  label: string;
  seconds: number;
  fields: string[];
  announcement?: string;
};
type AttentionProtocol = {
  instructions: string;
  startLabel: string;
  lineSeconds?: number;
  stages: Stage[];
};
type Session = {
  accessKey: string;
  applicationId: string;
  applicationSessionId: string;
  testId: string;
  instrumentId: string;
  protocolId: string;
  formSpec: {
    title: string;
    instructions?: string;
    fields: Field[];
    attentionProtocol?: AttentionProtocol;
    pfisterIdentity?: { patientId: string; evaluationId: string };
  };
};
const commandPages: Record<string, string[]> = {
  AD: ["ad-01"],
  AS: ["as-03"],
  TEALT: ["tealt-07"],
  "AC-15": ["ac15-09"],
  BPA: ["bpa-1", "bpa-3", "bpa-5"],
  "TADIM-2": ["tadim2-05"],
};
function CommandSheet({ test, stage }: { test: string; stage: number }) {
  const [practice, setPractice] = useState<Record<string, string>>({}),
    pages = commandPages[test] || [],
    page = pages[test === "BPA" ? stage : 0],
    imageUrl = page
      ? "/materials/protected_material_4f9c2d_" + page + ".png"
      : "";
  return page ? (
    <section>
      <p>
        {test === "AC-15"
          ? "Treino na folha de comandos — as marcações abaixo não entram na pontuação."
          : "Leia a folha de comandos antes de iniciar."}
      </p>
      {test === "AC-15" ? (
        <DrawingField
          key={page}
          field={{
            key: "practice:" + page,
            label: "Comandos e treino — " + test,
            type: "drawing",
            imageUrl,
          }}
          value={practice[page] || ""}
          onChange={(value) =>
            setPractice((old) => ({ ...old, [page]: value }))
          }
          attention
        />
      ) : (
        <div className="application-sheet command-sheet">
          <img src={imageUrl} alt={"Comandos — " + test} draggable={false} />
        </div>
      )}
    </section>
  ) : null;
}
type Stroke = Array<{ x: number; y: number }>;
function speak(text: string) {
  if (!("speechSynthesis" in window))
    throw new Error("Este navegador não oferece avisos de voz.");
  speechSynthesis.cancel();
  speechSynthesis.resume();
  const voice = new SpeechSynthesisUtterance(text);
  voice.lang = "pt-BR";
  voice.rate = 1;
  voice.onerror = (event) => console.error("[NeuroAvalia voz]", event.error);
  speechSynthesis.speak(voice);
}
function DrawingField({
  field,
  value,
  onChange,
  allowMark,
  attention,
}: {
  field: Field;
  value: string;
  onChange: (v: string) => void;
  allowMark?: (x: number, y: number) => boolean;
  attention?: boolean;
}) {
  const [strokes, setStrokes] = useState<Stroke[]>(() => {
      try {
        return value ? JSON.parse(value).strokes || [] : [];
      } catch {
        return [];
      }
    }),
    [draft, setDraft] = useState<Stroke>([]),
    active = useRef<number | null>(null),
    draftRef = useRef<Stroke>([]),
    strokesRef = useRef(strokes),
    mask = useRef<PixelSource | null>(null),
    horizontal = /_(as-04|ad-02|tealt-08)\.png$/.test(field.imageUrl || "");
  useEffect(() => {
    if (!attention || !field.imageUrl) return;
    let cancelled = false;
    const image = new Image();
    image.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = image.naturalWidth;
        canvas.height = image.naturalHeight;
        const context = canvas.getContext("2d", { willReadFrequently: true });
        context?.drawImage(image, 0, 0);
        const data = context?.getImageData(0, 0, canvas.width, canvas.height);
        if (data && !cancelled)
          mask.current = {
            data: data.data,
            width: data.width,
            height: data.height,
          };
      } catch (error) {
        console.error("[NeuroAvalia máscara espacial]", error);
      }
    };
    image.onerror = () =>
      console.error(
        "[NeuroAvalia máscara espacial] folha não carregada",
        field.imageUrl,
      );
    image.src = field.imageUrl;
    return () => {
      cancelled = true;
    };
  }, [field.imageUrl, attention]);
  function point(e: PointerEvent<SVGSVGElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    return {
      x: Math.round(((e.clientX - r.left) / r.width) * 1000),
      y: Math.round(((e.clientY - r.top) / r.height) * 1000),
    };
  }
  function save(next: Stroke[]) {
    strokesRef.current = next;
    setStrokes(next);
    onChange(
      JSON.stringify({
        version: 2,
        imageUrl: field.imageUrl,
        markCount: next.length,
        orientation: horizontal ? "landscape-ccw" : "original",
        strokes: next,
      }),
    );
  }
  function clearDraft() {
    draftRef.current = [];
    setDraft([]);
    active.current = null;
  }
  return (
    <div>
      <div
        className="application-sheet response-sheet"
        style={{ touchAction: "none" }}
      >
        {field.imageUrl &&
          (horizontal ? (
            <svg
              viewBox="0 0 1500 1000"
              role="img"
              aria-label={field.label}
              style={{
                position: "relative",
                display: "block",
                height: "auto",
                width: "100%",
              }}
            >
              <image
                href={field.imageUrl}
                width="1000"
                height="1500"
                transform="translate(0 1000) rotate(-90)"
              />
            </svg>
          ) : (
            <img src={field.imageUrl} alt={field.label} draggable={false} />
          ))}
        <svg
          viewBox="0 0 1000 1000"
          preserveAspectRatio="none"
          style={{ touchAction: "none" }}
          onPointerDown={(e) => {
            if (active.current !== null || (attention && !mask.current)) return;
            e.preventDefault?.();
            const p = point(e);
            e.currentTarget.setPointerCapture(e.pointerId);
            active.current = e.pointerId;
            draftRef.current = [p];
            setDraft([p]);
          }}
          onPointerMove={(e) => {
            if (active.current !== e.pointerId) return;
            e.preventDefault?.();
            const next =
              appendPoint([draftRef.current], point(e))[0] || draftRef.current;
            draftRef.current = next;
            setDraft(next);
          }}
          onPointerUp={(e) => {
            if (active.current !== e.pointerId) return;
            e.preventDefault?.();
            const stroke =
                appendPoint([draftRef.current], point(e))[0] ||
                draftRef.current,
              valid =
                (!attention ||
                  (!!mask.current &&
                    validAttentionStroke(field.key, stroke, mask.current))) &&
                (!allowMark || allowMark(stroke[0].x, stroke[0].y));
            if (valid) save([...strokesRef.current, stroke]);
            clearDraft();
          }}
          onPointerCancel={clearDraft}
          onLostPointerCapture={(e) => {
            if (active.current === e.pointerId) clearDraft();
          }}
        >
          {[...strokes, draft]
            .filter((s) => s.length)
            .map((s, i) =>
              s.length === 1 ? (
                <circle key={i} cx={s[0].x} cy={s[0].y} r="2" fill="#173f3a" />
              ) : (
                <polyline
                  key={i}
                  points={s.map((p) => `${p.x},${p.y}`).join(" ")}
                  fill="none"
                  stroke="#173f3a"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              ),
            )}
        </svg>
      </div>
      <div className="actions">
        <button
          type="button"
          onClick={() => save(strokesRef.current.slice(0, -1))}
          disabled={!strokes.length}
        >
          Desfazer última marca
        </button>
        <button
          type="button"
          onClick={() => save([])}
          disabled={!strokes.length}
        >
          Limpar folha
        </button>
      </div>
    </div>
  );
}
export default function RespondentPortal({
  token,
  previewSpec,
  selectedApplicationId,
  hub = false,
}: {
  token: string;
  previewSpec?: Session["formSpec"];
  selectedApplicationId?: string;
  hub?: boolean;
}) {
  const [saveState, setSaveState] = useState(""),
    [identifier, setIdentifier] = useState(""),
    [identifierKind, setIdentifierKind] = useState("name"),
    [session, setSession] = useState<Session | null>(null),
    [answers, setAnswers] = useState<Record<string, string | boolean>>({}),
    [error, setError] = useState(""),
    [done, setDone] = useState(false),
    [busy, setBusy] = useState(false),
    [started, setStarted] = useState(false),
    [stage, setStage] = useState(0),
    [remaining, setRemaining] = useState(0),
    [asRow, setAsRow] = useState(0);
  const saveChain = useRef<Promise<unknown>>(Promise.resolve());
  const asClock = useRef<ASLineClock | null>(null);
  const answersRef = useRef(answers),
    sessionRef = useRef(session),
    finishing = useRef(false);
  useEffect(() => {
    if (previewSpec)
      setSession({
        accessKey: "",
        applicationId: "preview",
        applicationSessionId: "preview",
        testId: previewSpec.title,
        instrumentId: "preview",
        protocolId: "preview",
        formSpec: previewSpec,
      });
    else if (hub)
      try {
        const saved = JSON.parse(
          sessionStorage.getItem(`neuroavalia-hub-${token}`) || "{}",
        );
        if (saved.identifier) setIdentifier(saved.identifier);
        if (saved.identifierKind) setIdentifierKind(saved.identifierKind);
      } catch {}
  }, [previewSpec, hub, token]);
  useEffect(() => {
    answersRef.current = answers;
  }, [answers]);
  useEffect(() => {
    sessionRef.current = session;
  }, [session]);
  useEffect(() => {
    if (previewSpec || !session || done) return;
    try {
      localStorage.setItem(
        `neuroavalia-draft-${session.applicationId}`,
        JSON.stringify(answers),
      );
    } catch {}
  }, [answers, session, done]);
  useEffect(() => {
    if (previewSpec || !session || done || !Object.keys(answers).length) return;
    let cancelled = false;
    const timer = setTimeout(() => {
      saveChain.current = saveChain.current.then(async () => {
        try {
          setSaveState("Salvando respostas…");
          const r = await fetch("/api/respondent/submit", {
            method: "PATCH",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              token,
              applicationId: selectedApplicationId,
              accessKey: session.accessKey,
              answers,
            }),
          });
          if (!r.ok) throw new Error();
          if (!cancelled)
            setSaveState("Respostas salvas para conferência profissional.");
        } catch {
          if (!cancelled)
            setSaveState(
              "Falha ao salvar online. Mantenha a página aberta e confira sua conexão.",
            );
        }
      });
    }, 800);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [answers, session, done, token, selectedApplicationId, previewSpec]);
  useEffect(() => {
    if (!started || done || !session?.formSpec.attentionProtocol) return;
    if (session.testId === "AS") {
      const clock = asClock.current;
      if (!clock) return;
      const timer = setInterval(() => {
        if (clock.tick(Date.now())) {
          setAsRow(clock.row);
          if (clock.done) {
            clearInterval(timer);
            speak("Tempo encerrado");
            void finish(true);
          } else speak("Próxima");
        }
        setRemaining(clock.remaining(Date.now()));
      }, 100);
      return () => clearInterval(timer);
    }
    const protocol = session.formSpec.attentionProtocol,
      deadline = Date.now() + protocol.stages[stage].seconds * 1000;
    let lastLine = 0;
    const t = setInterval(() => {
      const next = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      setRemaining(next);
      const line = protocol.lineSeconds
        ? Math.floor(
            (protocol.stages[stage].seconds - next) / protocol.lineSeconds,
          )
        : 0;
      if (line > lastLine && next > 0) {
        lastLine = line;
        speak("Próxima");
      }
      if (next > 0) return;
      clearInterval(t);
      const current = protocol.stages[stage];
      if (current.announcement) speak(current.announcement);
      if (stage < protocol.stages.length - 1) {
        const nextStage = stage + 1;
        setStage(nextStage);
        if (session.testId === "BPA") setStarted(false);
        else initializeStage(nextStage, protocol);
        return;
      }
      void finish(true);
    }, 250);
    return () => clearInterval(t);
  }, [started, stage, done, session]);
  function initializeStage(index: number, protocol: AttentionProtocol) {
    const keys = protocol.stages[index]?.fields || [];
    setAnswers((old) => {
      const next = { ...old };
      for (const key of keys)
        if (next[key] === undefined) {
          const field = sessionRef.current?.formSpec.fields.find(
            (f) => f.key === key,
          );
          next[key] = JSON.stringify({
            version: 2,
            imageUrl: field?.imageUrl,
            markCount: 0,
            strokes: [],
          });
        }
      return next;
    });
  }
  async function start() {
    if (previewSpec) return;
    setBusy(true);
    setError("");
    const r = await fetch("/api/respondent/access", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        token,
        identifier,
        identifierKind,
        applicationId: selectedApplicationId,
      }),
    });
    const x = await r.json();
    setBusy(false);
    if (!r.ok) return setError(x.error);
    try {
      const draft = localStorage.getItem(
        `neuroavalia-draft-${x.applicationId}`,
      );
      if (draft) setAnswers(JSON.parse(draft));
    } catch {}
    setSession(x);
  }
  function beginTimed() {
    const protocol = session?.formSpec.attentionProtocol;
    if (!protocol) return;
    try {
      speak("Iniciar");
    } catch (error) {
      setError(String(error));
      return;
    }
    initializeStage(stage, protocol);
    if (session?.testId === "AS") {
      asClock.current = new ASLineClock(Date.now());
      setAsRow(0);
      setRemaining(15);
    } else setRemaining(protocol.stages[stage].seconds);
    setStarted(true);
  }
  async function finish(timed = false) {
    if (previewSpec) {
      setDone(true);
      return;
    }
    const active = sessionRef.current;
    if (!active || finishing.current) return;
    const currentAnswers = answersRef.current,
      requiredFields = active.formSpec.fields.filter(
        (f) => !timed && f.required && f.type !== "drawing",
      );
    const missing = requiredFields.filter(
      (f) =>
        currentAnswers[f.key] === undefined || currentAnswers[f.key] === "",
    );
    if (active.testId === "Pfister") {
      try {
        if (!isPfisterProtocolComplete(JSON.parse(String(currentAnswers["pfister:protocol"] || "")))) {
          setError("Conclua as três pirâmides e responda todo o inquérito antes de finalizar.");
          return;
        }
      } catch {
        setError("O protocolo do Pfister ainda não está completo.");
        return;
      }
    }
    if (missing.length) {
      setError(
        "Não foi possível concluir. Confira somente os campos administrativos obrigatórios.",
      );
      return;
    }
    finishing.current = true;
    setBusy(true);
    await saveChain.current;
    const r = await fetch("/api/respondent/submit", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        token,
        applicationId: selectedApplicationId,
        accessKey: active.accessKey,
        answers: currentAnswers,
      }),
    });
    const x = await r.json();
    setBusy(false);
    finishing.current = false;
    if (!r.ok) return setError(x.error);
    try {
      localStorage.removeItem(`neuroavalia-draft-${active.applicationId}`);
    } catch {}
    setDone(true);
  }
  const set = (key: string, value: string | boolean) => {
    const next = { ...answersRef.current, [key]: value };
    answersRef.current = next;
    setAnswers(next);
  };
  if (done)
    return (
      <main className="respondent-shell">
        <section className="questionnaire">
          <p className="eyebrow">NEUROAVALIA</p>
          <h1>Avaliação finalizada</h1>
          <div className="notice">
            {previewSpec
              ? "Visualização encerrada. Nenhuma resposta foi enviada ou salva."
              : "Suas respostas foram enviadas ao profissional e este teste foi encerrado."}
          </div>
          {hub && (
            <div className="actions">
              <a className="primary-button" href={`/p/${token}`}>
                Voltar aos testes liberados
              </a>
            </div>
          )}
        </section>
      </main>
    );
  if (!session)
    return (
      <main className="respondent-shell">
        <section className="questionnaire">
          <p className="eyebrow">NEUROAVALIA</p>
          <h1>
            {hub
              ? "Confirmar abertura do teste"
              : "Compreender para cuidar melhor"}
          </h1>
          <p className="subtitle">
            {hub
              ? "Ao abrir, este teste ficará vinculado a esta única realização."
              : "Confirme sua identificação. Este link permite uma única abertura."}
          </p>
          <div className="field">
            <label>
              Nome, CPF ou data de nascimento informada ao profissional
            </label>
            <input
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              autoComplete="off"
            />
          </div>
          {error && <div className="notice error">{error}</div>}
          <div className="actions">
            <button
              className="primary-button"
              onClick={start}
              disabled={busy || !identifier}
            >
              {busy ? "Validando..." : "Abrir avaliação"}
            </button>
            {hub && <a href={`/p/${token}`}>Voltar</a>}
          </div>
        </section>
      </main>
    );
  const protocol = session.formSpec.attentionProtocol;
  if (protocol && !started)
    return (
      <main className="respondent-shell">
        <section className="questionnaire">
          <p className="eyebrow">NEUROAVALIA</p>
          <h1>{session.formSpec.title}</h1>
          <p className="subtitle">{protocol.instructions}</p>
          <CommandSheet test={session.testId} stage={stage} />
          {error && (
            <div role="alert" className="notice error">
              {error}
            </div>
          )}
          <div className="notice error">
            <b>Atenção:</b> o cronômetro começa ao tocar no botão abaixo e não
            poderá ser reiniciado. Não saia nem recarregue a página.
          </div>
          <div className="actions">
            <button className="primary-button" onClick={beginTimed}>
              {stage === 0
                ? protocol.startLabel
                : "Virar a folha e iniciar — " + protocol.stages[stage].label}
            </button>
          </div>
        </section>
      </main>
    );
  const visibleFields = protocol
    ? session.formSpec.fields.filter((f) =>
        protocol.stages[stage]?.fields.includes(f.key),
      )
    : session.formSpec.fields;
  const minutes = Math.floor(remaining / 60),
    seconds = remaining % 60;
  return (
    <main className="respondent-shell">
      <section className="questionnaire timed-questionnaire">
        <p className="eyebrow">NEUROAVALIA</p>
        <h1>{session.formSpec.title || session.testId}</h1>
        {protocol ? (
          <div className="timer-panel">
            <b>
              {protocol.stages[stage].label}
              {session.testId === "AS" ? ` — Linha ${asRow + 1} de 25` : ""}
            </b>
            <span>
              {minutes}:{String(seconds).padStart(2, "0")}
            </span>
          </div>
        ) : (
          session.formSpec.instructions && (
            <p className="subtitle">{session.formSpec.instructions}</p>
          )
        )}
        {saveState.startsWith("Falha") && (
          <div role="alert" className="notice error">
            {saveState}
          </div>
        )}
        <div className="notice">
          {protocol
            ? "Marque diretamente na folha conforme o comando do teste."
            : "Realize a avaliação conforme as instruções apresentadas."}
        </div>
        {!protocol && <CommandSheet test={session.testId} stage={0} />}
        {session.testId === "Pfister" && session.formSpec.pfisterIdentity ? (
          <PfisterResponse value={String(answers["pfister:protocol"] || "")} onChange={(value)=>set("pfister:protocol",value)} patientId={session.formSpec.pfisterIdentity.patientId} evaluationId={session.formSpec.pfisterIdentity.evaluationId} applicationId={session.applicationId}/>
        ) : visibleFields.map((f, i) => (
          <div className="question" key={f.key}>
            <b>
              {i + 1}. {f.label}
              {f.required && !protocol ? " *" : ""}
            </b>
            {f.type === "drawing" ? (
              <DrawingField
                key={f.key}
                field={f}
                value={String(answers[f.key] ?? "")}
                onChange={(v) => set(f.key, v)}
                attention={!!protocol}
                allowMark={
                  session.testId === "AS"
                    ? (x, y) => {
                        const row = asRowAt(x, y),
                          clock = asClock.current;
                        if (
                          row === null ||
                          !clock ||
                          !clock.mark(row, Date.now())
                        )
                          return false;
                        setAsRow(clock.row);
                        setRemaining(clock.remaining(Date.now()));
                        return true;
                      }
                    : undefined
                }
              />
            ) : f.type === "radio" ? (
              <div className="choices">
                {(f.options || []).map((o) => (
                  <label className="choice" key={o.value}>
                    <input
                      type="radio"
                      name={f.key}
                      checked={String(answers[f.key] ?? "") === o.value}
                      onChange={() => set(f.key, o.value)}
                    />
                    {o.label}
                  </label>
                ))}
              </div>
            ) : f.type === "checkbox" ? (
              <label className="choice">
                <input
                  type="checkbox"
                  checked={Boolean(answers[f.key])}
                  onChange={(e) => set(f.key, e.target.checked)}
                />{" "}
                Sim
              </label>
            ) : f.type === "select" ? (
              <select
                value={String(answers[f.key] ?? "")}
                onChange={(e) => set(f.key, e.target.value)}
              >
                <option value="">Selecione</option>
                {(f.options || []).map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            ) : f.type === "textarea" ? (
              <textarea
                value={String(answers[f.key] ?? "")}
                onChange={(e) => set(f.key, e.target.value)}
              />
            ) : (
              <input
                type={f.type}
                value={String(answers[f.key] ?? "")}
                onChange={(e) => set(f.key, e.target.value)}
              />
            )}
          </div>
        ))}
        {error && <div className="notice error">{error}</div>}
        {!protocol && (
          <div className="actions">
            <button
              className="primary-button"
              onClick={() => finish(false)}
              disabled={busy}
            >
              {busy ? "Enviando..." : "Finalizar avaliação"}
            </button>
          </div>
        )}
      </section>
    </main>
  );
}
