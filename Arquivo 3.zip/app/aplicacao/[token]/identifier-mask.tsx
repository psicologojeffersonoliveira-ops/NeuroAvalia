"use client";
import {useEffect} from "react";
import {formatBirth,formatCpf,IdentifierKind} from "../../lib/respondent-identity";

export default function IdentifierMask(){
 useEffect(()=>{let input:HTMLInputElement|null=null,field:HTMLDivElement|null=null,kind:IdentifierKind="name";const nativeFetch=window.fetch;
  window.fetch=(async(inputUrl:RequestInfo|URL,init?:RequestInit)=>{if(String(inputUrl)==='/api/respondent/access'&&typeof init?.body==='string'){try{const body=JSON.parse(init.body);body.identifierKind=kind;init={...init,body:JSON.stringify(body)}}catch{}}return nativeFetch(inputUrl,init)}) as typeof window.fetch;
  const install=()=>{input=document.querySelector('.questionnaire input[autocomplete="off"]');if(!input||document.querySelector('[data-identifier-kind]'))return;
   field=document.createElement('div');field.className='field';field.dataset.identifierKind='';const label=document.createElement('label'),select=document.createElement('select');label.textContent='Forma de identificação';
   for(const [value,text] of [['name','Nome'],['cpf','CPF'],['birth','Data de nascimento']]){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option)}
   select.onchange=()=>{kind=select.value as IdentifierKind;if(input){const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;setter?.call(input,'');input.dispatchEvent(new Event('input',{bubbles:true}));input.placeholder=kind==='cpf'?'000.000.000-00':kind==='birth'?'DD/MM/AAAA':'Nome completo';input.inputMode=kind==='name'?'text':'numeric'}};
   const format=()=>{if(!input)return;const value=kind==='cpf'?formatCpf(input.value):kind==='birth'?formatBirth(input.value):input.value;if(value!==input.value)Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set?.call(input,value)};
   input.addEventListener('input',format,true);label.append(select);field.append(label);input.parentElement?.before(field)};
  const observer=new MutationObserver(install);observer.observe(document.body,{childList:true,subtree:true});install();return()=>{observer.disconnect();window.fetch=nativeFetch;field?.remove()}
 },[]);return null;
}
