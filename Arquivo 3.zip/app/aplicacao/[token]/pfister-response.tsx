"use client";
import { useMemo, useState } from "react";
import { PFISTER_COLORS, type PfisterColorCode } from "../../lib/pfister-colors";
import { PFISTER_POSITIONS, reconstructPyramid, type PfisterPlacement, type PfisterPosition, type PfisterProtocol, type PfisterPyramid } from "../../lib/pfister-engine";

const INQUIRY = [
  ["mostBeautiful", "Qual pirâmide ficou mais bonita? De qual você mais gosta? Por quê?"],
  ["leastBeautiful", "De qual pirâmide você menos gosta? Por quê?"],
  ["favoriteGeneral", "Geralmente, de qual cor você gosta mais?"],
  ["leastGeneral", "De qual cor você menos gosta em geral?"],
  ["favoriteMaterial", "Aqui no teste, qual é sua cor preferida?"],
  ["leastMaterial", "De qual cor do material você menos gostou?"],
  ["closing", "O que achou do teste e como está se sentindo? Deseja acrescentar algo?"],
] as const;

function emptyProtocol(patientId:string,evaluationId:string,applicationId:string):PfisterProtocol{return{schemaVersion:1,patientId,evaluationId,applicationId,testId:"Pfister",placements:[],startedAt:Date.now(),inquiry:{}}}
function readProtocol(value:string,patientId:string,evaluationId:string,applicationId:string){try{const parsed=JSON.parse(value) as PfisterProtocol;if(parsed.patientId===patientId&&parsed.evaluationId===evaluationId&&parsed.applicationId===applicationId&&parsed.testId==="Pfister")return parsed}catch{}return emptyProtocol(patientId,evaluationId,applicationId)}

function Pyramid({protocol,pyramid,selected,onPlace}:{protocol:PfisterProtocol;pyramid:PfisterPyramid;selected:PfisterColorCode;onPlace?:(position:PfisterPosition,color?:PfisterColorCode)=>void}){
  const result=useMemo(()=>reconstructPyramid(protocol,pyramid),[protocol,pyramid]);
  return <div className="pfister-pyramid" aria-label={`Pirâmide ${pyramid}`}>{PFISTER_POSITIONS.map(position=>{const code=result.final[position],color=code?PFISTER_COLORS.find(x=>x.code===code):null;return <button key={position} type="button" className={`pfister-cell pfister-${position}`} onClick={()=>onPlace?.(position)} onDragOver={event=>{if(onPlace)event.preventDefault()}} onDrop={event=>{event.preventDefault();const dragged=event.dataTransfer.getData("application/x-pfister-color") as PfisterColorCode;onPlace?.(position,dragged||selected)}} style={{background:color?.hex||"#fffdf8"}} aria-label={`Espaço ${position}${color?", preenchido":" vazio"}`}/>})}</div>
}

export function PfisterResponse({value,onChange,patientId,evaluationId,applicationId}:{value:string;onChange:(value:string)=>void;patientId:string;evaluationId:string;applicationId:string}){
  const [protocol,setProtocol]=useState(()=>readProtocol(value,patientId,evaluationId,applicationId)),[pyramid,setPyramid]=useState<PfisterPyramid>(1),[selected,setSelected]=useState<PfisterColorCode>("Az1"),[inquiry,setInquiry]=useState(false);
  const result=useMemo(()=>reconstructPyramid(protocol,pyramid),[protocol,pyramid]);
  function commit(next:PfisterProtocol){setProtocol(next);onChange(JSON.stringify(next))}
  function place(position:PfisterPosition,color:PfisterColorCode=selected){const sequence=protocol.placements.length+1,event:PfisterPlacement={eventId:crypto.randomUUID(),sequence,pyramid,position,color,recordedAt:Date.now()};commit({...protocol,placements:[...protocol.placements,event]})}
  function undo(){const index=protocol.placements.findLastIndex(event=>event.pyramid===pyramid);if(index<0)return;commit({...protocol,placements:protocol.placements.filter((_,i)=>i!==index).map((event,i)=>({...event,sequence:i+1}))})}
  function advance(){if(!result.complete)return;if(pyramid<3)setPyramid((pyramid+1) as PfisterPyramid);else setInquiry(true)}
  const palette=<div className="pfister-palette" aria-label="Cores e tonalidades">{PFISTER_COLORS.map(color=><button key={color.code} type="button" draggable aria-pressed={selected===color.code} aria-label="Selecionar cor" onDragStart={event=>{setSelected(color.code);event.dataTransfer.effectAllowed="copy";event.dataTransfer.setData("application/x-pfister-color",color.code)}} onClick={()=>setSelected(color.code)} style={{background:color.hex}}/>)}</div>;
  if(inquiry)return <section className="pfister-response"><div className="pfister-completed"><h2>As três pirâmides</h2><div className="pfister-three">{([1,2,3] as PfisterPyramid[]).map(value=><div key={value}><b>Pirâmide {value}</b><Pyramid protocol={protocol} pyramid={value} selected={selected}/></div>)}</div></div><section className="pfister-inquiry"><h2>Inquérito final</h2>{INQUIRY.map(([key,label])=><label key={key}><span>{label}</span><textarea value={protocol.inquiry?.[key]||""} onChange={event=>commit({...protocol,inquiry:{...protocol.inquiry,[key]:event.target.value}})}/></label>)}</section></section>;
  return <section className="pfister-response"><div className="notice">Pirâmide {pyramid} de 3. Selecione uma cor e clique no espaço escolhido, ou arraste a cor diretamente para ele.</div><div className="pfister-workspace"><aside>{palette}</aside><Pyramid protocol={protocol} pyramid={pyramid} selected={selected} onPlace={place}/><aside className="pfister-palette-mirror" aria-hidden="true">{palette}</aside></div><div className="actions"><button type="button" onClick={undo} disabled={!result.placementCount}>Desfazer última colocação</button><button type="button" className="primary-button" disabled={!result.complete} onClick={advance}>{pyramid<3?"Concluir e abrir próxima pirâmide":"Mostrar as três pirâmides e abrir inquérito"}</button></div></section>
}
