# NeuroAvalia — auditoria de regressões

**Intervenção parcial. Sem aprovação funcional ou declaração de zero regressão.**

## Fonte examinada

Publicação consultada: versão 25, fonte `7b73bac96f582b3927644ebfb15235f03c62f82b`, preservada no histórico Git.

A tabela de ativação em produção aponta para `NeuroAvalia_Com_Todos_Os_Dados_2026-08-25.html`, SHA-256 `a12d7842e1bc6fcd963ca22a50000982bee4ae045e6121436258f07c18dc3973`. Uma cópia do arquivo enviado foi recuperada e apresentou exatamente esse SHA.

O arquivo contém 17 pacientes, 18 avaliações e 137 compromissos. Os registros de preservação no servidor informam 20 pacientes, 20 avaliações e 164 compromissos. As três importações consultadas permanecem em RESTAURANDO, sem restored_at. Essas contagens NÃO comprovam que o conteúdo preservado ainda esteja disponível no navegador nem identificam quais pacientes faltam.

## Arquitetura e achados

- O banco D1 de produção contém `online_applications`, `neuroavalia_imports` e `neuroavalia_active_html`. Não há tabela de cadastro clínico centralizado entre dispositivos.
- Cadastro, agenda, bateria e laudo são hidratados do IndexedDB do navegador (`NeuroAvaliaPersistentStore/state/neuroavalia_persist_v15`). O arquivo HTML é a fonte inicial quando não há IndexedDB. Isso pode apresentar uma base mais antiga em outro navegador/dispositivo; a recuperação real ainda exige a comparação com o navegador afetado.
- A preservação anterior à restauração é guardada em outro IndexedDB, `NeuroAvaliaOnlineRestoreVault`. O servidor registra contagens, não uma cópia dessa base completa.
- A publicação utiliza acesso global `custom`. As rotas do respondente não exigem getChatGPTUser, mas o controle anterior à aplicação impede acesso anônimo. A ferramenta de configuração disponível oferece alteração global, sem exceção por rota. Não foi alterada para public, nem distribuído token de bypass.
- A conclusão retornava sucesso sem testar se o UPDATE efetivamente alterou uma linha. Isso foi corrigido.
- Foram encontradas duas ocorrências textuais de reportCollectRows, reportDocumentHTML e reportDomainSectionsHTML no HTML fonte. Isso não basta para determinar duplicidade efetiva: podem existir cópias serializadas/inertes. Não foram removidas nem reescritas funções clínicas com base apenas nessa contagem.
- A consulta de erros de produção trouxe um pedido cancelado da rota profissional, não uma prova de exclusão de dados. Não foi possível consultar o console do navegador afetado.

## Alterações limitadas

- `app/lib/patient-diagnostics.ts`: comparação somente leitura entre memória, HTML incorporado, IndexedDB, cópia local legada e preservação anterior. Exibe nomes/IDs apenas ao profissional e permite exportar o diagnóstico. Não recria, funde ou sobrescreve pacientes.
- `app/api/professional/neuroavalia/route.ts`: injeta o diagnóstico e lê a contagem da preservação. Quando não existe IndexedDB e o HTML possui menos pacientes que a preservação, bloqueia o salvamento inicial e avisa que é necessária recuperação. A proteção não impede o carregamento de uma base existente com exclusões legítimas.
- `app/profissional/visualizar/page.tsx` e `preview.tsx`: visualização profissional autenticada.
- `app/aplicacao/[token]/respondent.tsx`: mesmo renderer da aplicação real em modo explícito de visualização, sem gravação local, envio ou conclusão clínica.
- `app/lib/neuro-remote-integration.ts`: botão Visualizar entre Abrir teste e Enviar link; religa ações exportadas sem handler em vez de considerá-las funcionais só pela presença no DOM.
- `app/api/respondent/submit/route.ts`: conclusão somente confirmada quando o banco informa alteração; preserva token, chave de acesso e condição de estado.
- `tests/patient-review.test.mjs`: cobertura dos novos limites.

Não houve migration, reset, seed, exclusão, restauração automática ou atualização de registros clínicos. Não foram alterados crivos, normas, itens, comandos ou classificações. Não foram criados pacientes fictícios em produção nesta intervenção.

## Testes e evidências

Os resultados individuais dos 49 testes de código estão em `regression-tests-2026-08-28.tap`. Eles incluem as verificações anteriores; NÃO representam 49 instrumentos aplicados online. A primeira execução encontrou dependências locais ausentes após manutenção do ambiente; a instalação bloqueada pelo lockfile foi recuperada e a execução completa passou.

| Verificação | Estado | Evidência / limite |
| --- | --- | --- |
| Código: comparação de fontes sem mutação | PASS | Teste unitário com pacientes diferentes por origem |
| Código: proteção contra base inicial menor | PASS | Sem IndexedDB bloqueia; com IndexedDB existente não bloqueia |
| Código: visualização compartilha renderer e desliga gravação | PASS | Contrato de implementação; não substitui clique no navegador |
| Código: conclusão condicionada ao banco | PASS | Condição de meta.changes no endpoint |
| Código: demais verificações de retorno, captura, agenda e validação | PASS | Arquivo TAP, 49 testes totais |
| Link sem login, privado, nova sessão e usuário novo | NÃO RESOLVIDO / NÃO EXECUTADO | Publicação continua restrita; não foi exposto o sistema inteiro |
| Recuperar pacientes desaparecidos | NÃO RESOLVIDO | Comparação no navegador afetado ainda necessária |
| Persistência após reload / fechar / reabrir / outro dispositivo | NÃO COMPROVADO | Não há acesso ao IndexedDB do usuário; não há base clínica centralizada |
| 1-1-1 multipaciente e multirrespondente real | NÃO COMPROVADO | Apenas testes simulados de partes do retorno; sem aplicação real completa |
| Automação de todos os instrumentos até o laudo | NÃO COMPROVADO | Não foram produzidos resultados clínicos artificiais |
| Visualizar / Abrir / Enviar em navegador real | NÃO EXECUTADO | Bloqueio anterior da política do navegador; não contornado |
| Ausência global de regressões | NÃO COMPROVADO | Não declarada |

## Próximo dado necessário

No mesmo navegador e perfil onde os pacientes sumiram, abrir **Diagnosticar pacientes** e salvar o diagnóstico. Comparar os IDs e nomes ausentes com a cópia preservada, distinguindo exclusões intencionais. Antes de qualquer restauração, preservar a base atual e selecionar precisamente a origem e os registros a recuperar.

Acesso público por token requer uma solução de entrada pública restrita aos recursos autorizados, com autorização profissional efetiva no servidor e proteção dos recursos estáticos. Não basta remover o login do componente, usar um bypass global ou alterar publicamente toda a publicação sem comprovar essa separação.
