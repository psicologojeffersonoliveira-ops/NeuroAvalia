# Auditoria de recuperação, acesso e percurso clínico — 2026-08-29

Este documento separa evidência automatizada de validação humana em produção. Nenhuma linha PENDENTE deve ser interpretada como aprovação clínica ou operacional.

| Teste | Estado | Evidência |
|---|---|---|
| Recuperação de Olivia, Pedro e dos dois cadastros Jefferson sem mesclar homônimos | PASS automatizado | Teste de hidratação adiciona somente IDs ausentes e não substitui pacientes, agenda ou testes existentes. |
| Salvamento automático no servidor e reabertura em nova sessão | PASS automatizado | Escrita serializada, confirmação do servidor, snapshot versionado e bloqueio de revisão concorrente exercitados. |
| Importação de HTML preservada | PASS automatizado | Integração é reinjetada uma única vez inclusive após exportação; acesso de importação permanece disponível. |
| Identificação por nome, CPF ou nascimento | PASS automatizado | Normalização, máscara, validação de calendário e isolamento entre tipos cobertos. Somente hashes são gravados na aplicação online. |
| Link de aplicação sem conta ChatGPT | PASS de configuração / PENDENTE navegador externo | Rota do respondente continua sem autenticação profissional e o projeto será configurado como público. Conferência em janela anônima externa permanece obrigatória. |
| Área profissional protegida | PASS estrutural | Páginas e APIs profissionais mantêm autenticação; a liberação pública do domínio não remove essa barreira interna. |
| Relação paciente → avaliação → aplicação | PASS automatizado | Consultas são específicas por profissional, paciente e avaliação; aplicação mantém ID próprio e tipo de respondente. |
| Visualizar resposta realizada | PASS automatizado / PENDENTE navegador | Renderizador recebe a aplicação exata e exibe os campos somente leitura, inclusive traços persistidos; comparação visual A/B em produção ainda é obrigatória. |
| Traços dos testes de atenção | PASS automatizado | Pontos inicial/final, traços rápidos, coordenadas, folha correta e retorno idêntico foram exercitados. A velocidade não substitui a contagem do traço registrado. |
| Validação espacial individual — AD, AS, TEALT, AC-15 e BPA | PASS automatizado | Cada folha usa seus próprios limites, orientação e imagem real. Margens, rodapé e áreas sem estímulo são rejeitados; uma tolerância de 13/1000 preserva a marcação humana próxima ao estímulo. |
| Folhas de exemplo/comando | PASS automatizado | A validação clínica é aplicada somente ao protocolo pontuável; a folha de comando não recebe o atributo de pontuação. |
| BPA — marcação → alvo/não alvo | PASS automatizado | As três folhas e seus 400 estímulos foram exercitados individualmente contra o crivo protegido. Marcação rápida/lenta produz a mesma leitura; cruzamento ambíguo não vira acerto. Omissão clínica não é inventada. |
| AD, AS, AC-15 e TEALT — geometria → bruto clínico automático | **FAIL / PENDENTE crivo oficial** | Os traços válidos ficam preservados para conferência e correção profissional, mas o repositório não contém mapas espaciais oficiais de alvos desses instrumentos. Criar bruto a partir da aparência da folha fabricaria um resultado clínico; portanto a automação permanece bloqueada até a incorporação dos crivos autoritativos. |
| Percurso online → profissional → correção → laudo | PASS de invariantes / PENDENTE E2E humano | O validador bloqueia etapas ausentes, divergências, reutilização entre avaliações e persistência não confirmada. A aprovação final por instrumento exige execução humana real. |
| Agenda — viagem, avião, Unimed e contagem dos cartões | PASS automatizado | Viagem mantém ida, volta, origem e destino e desativa requisitos clínicos; avião e regras de Unimed permanecem cobertos sem reintroduzir contagem nos cartões. |
| Suíte selecionada | PASS | 66 testes aprovados, 0 falhas, e compilação de produção concluída. |

## Alterações desta versão

- campos identificadores normalizados e mascarados no acesso online;
- CPF persistido no cadastro clínico e enviado como identificador do link;
- hashes separados para nome, CPF e nascimento, mantendo compatibilidade com links anteriores;
- visualização reconstruída a partir da aplicação respondida, sem controles de edição;
- recuperação e salvamento automático protegidos contra sobrescrita concorrente;
- filtro espacial baseado na própria folha impede que margens, instruções, rodapé e vazios sejam registrados como resposta pontuável;
- geometria original dos traços aceitos permanece salva para reprodução exata na conferência profissional;
- migração aditiva: três colunas de hash opcionais, sem exclusão ou alteração de dados clínicos.

## Critério de encerramento

A versão não recebe selo de aprovação total enquanto não forem conferidos em produção: acesso anônimo por link, presença dos pacientes recuperados na sessão da responsável, duas aplicações distintas A/B na tela Visualizar e um percurso real completo por instrumento.

## Correção de raiz nº 6 — evidência AC-15

| Teste | Estado | Evidência |
|---|---|---|
| Reprodução do erro da imagem | PASS | As duas capturas reais mostram riscos persistidos desde a margem e atravessando título, instruções e vários itens; a auditoria localizou o salvamento em cada `pointermove`, após validação apenas do ponto inicial. |
| Canvas livre | PASS automatizado | A captura passou a manter um gesto provisório e só chama a persistência depois da validação integral. Gesto rejeitado não entra em respostas, autosave, desfazer nem folha respondida. |
| Título e instruções | PASS automatizado | A folha de comando AC-15 possui limites exclusivos para exemplos/treino; título e instruções ficam fora da região interativa válida. |
| Margens esquerda/direita, rodapé e vazio | PASS automatizado | Limites normalizados e máscara da imagem real rejeitam pontos sem estímulo, laterais e rodapé. |
| Rabisco longo | PASS automatizado | Extensão, altura, comprimento acumulado, linearidade e proporção próxima ao estímulo impedem diagonal ou risco de página de virar uma ou várias respostas. |
| Sublinhado válido | PASS automatizado | Gesto horizontal localizado próximo à palavra/linha é aceito e mantém sua geometria normalizada original. |
| Tolerância humana | PASS automatizado | Pequena inclinação, diferença de comprimento e deslocamento dentro da região recebem tolerância; velocidade não participa do critério. |
| Marcos 5/10/15 e letra V | PASS regressão | Protocolo, três etapas, avisos e folha original de comando não foram alterados. |
| Treino | PASS automatizado | O treino recebe a mesma proteção contra rabisco livre, mas continua em estado local separado e não integra bruto ou pontuação. |
| Celular | PASS estrutural / PENDENTE reteste humano | Coordenadas permanecem normalizadas e o AC-15 permite gesto horizontal com rolagem vertical; as capturas do usuário são a evidência pré-correção. Repetição no aparelho real após a publicação continua obrigatória. |
| Desktop | PASS estrutural / PENDENTE reteste humano | A regra independe do tamanho renderizado; repetição manual no navegador real continua obrigatória. |
| Folha respondida | PASS automatizado | Somente traços aprovados entram no JSON preservado e na reconstrução somente leitura. |
| Bruto AC-15 | **FAIL / PENDENTE crivo oficial** | A captura inválida foi bloqueada, mas não existe mapa autoritativo de alvos AC-15 no repositório. O sistema não fabricará bruto clínico. |
| Automação e 1-1-1 | PASS de invariantes / PENDENTE E2E clínico | Isolamento de aplicação, resposta, paciente, avaliação e laudo passou; percurso clínico real depende do crivo oficial e de conferência humana. |
| Pacientes e travamento inicial | PASS automatizado | Hidratação preserva pacientes antes de limpar seleção; recuperação é aditiva e não sobrescreve estado mais novo. |
| Agenda | PASS automatizado | Viagem, avião, ida/volta, Unimed e ausência de contagem nos cartões permanecem cobertos. |
| Autosave | PASS automatizado | Alteração, gravação confirmada, reabertura e proteção contra revisão concorrente permanecem cobertas. |
| Suíte dirigida completa | PASS | 67 testes aprovados e 0 falhas antes da compilação de produção. |
| Deploy | PENDENTE | Será atualizado após a verificação terminal da publicação desta candidata. |
