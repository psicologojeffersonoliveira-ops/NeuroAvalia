# Validação do percurso dos instrumentos

Abra **Testes → Validar percurso dos testes** no profissional autenticado.

1. O painel reúne o catálogo e os instrumentos de envio online. Nenhum começa aprovado.
2. **Preparar instrumento** cria um paciente fictício com bateria exclusiva. Não copia dados de pacientes reais.
3. **Modelo do caso** exporta o esquema real de aplicação. Preencha o JSON com referência independente (manual/edição/página), dados demográficos fictícios, respostas esperadas, caminhos do bruto em `raw`, linhas completas de `reportCollectRows` em `rows` e células textuais das tabelas em `reportRows`. O modelo vazio não é um caso validado.
4. Importe o caso. Outro paciente fictício exclusivo e uma aplicação normal são criados. Os valores esperados não são inseridos no motor clínico.
5. Responda pelo link usando o nome fictício mostrado no cadastro como identificação. Não há bypass de autenticação ou envio automático de respostas.
6. Use **Verificar** ou **Verificar todos os casos**. O mecanismo consulta a aplicação do profissional, executa o retorno existente, relê o IndexedDB, compara bruto e linhas calculadas e gera o documento de laudo para conferir suas tabelas.
7. Confirme os comandos somente após observar instruções, itens, folhas, voz e tempos na aplicação real. Essa etapa é atestação humana, não teste automático do navegador.
8. Exporte as evidências. Os casos também acompanham a persistência e o backup clínico existentes, identificados como fictícios.

## Contrato de caso

- `answers`: valores exatos para itens. Para desenhos, use `{ "drawing": true, "imageUrl": "/materials/...png" }`. Isso permite coordenadas livres. O bruto e a leitura esperada devem ser conferidos nos caminhos de `raw`. As respostas efetivamente recebidas devem chegar ao profissional sem modificação.
- `raw`: mapa entre caminhos no registro do instrumento e valores esperados. Zero é válido; ausência não é zero.
- `rows`: array completo, ordenado, de resultados esperados, incluindo medida, resultado, norma, percentil e classificação conforme o instrumento.
- `reportRows`: uma linha de células por resultado, na mesma ordem; deve conter medida, resultado e classificação. Linhas duplicadas não reutilizam a mesma ocorrência do laudo.
- Cada caso deve ter fonte independente. Não derive o valor esperado do próprio resultado observado.

## Limites explícitos

O mecanismo é uma infraestrutura de validação guiada. Não inclui automaticamente casos normativos conferidos para todos os instrumentos e não corrige motores ou crivos ausentes. Um caso positivo não cobre todas as idades, respondentes, limites normativos e situações de erro; essas variações exigem casos próprios.

Material recebido com correção pendente não passa. Falhas de persistência, respostas divergentes, identificação incorreta, resultado faltante ou laudo incompleto impedem aprovação. Mudança no HTML efetivo (incluindo integração atual) altera a impressão SHA-256 e exige novos casos. Não há certificação clínica nem aprovação global automática.

A conferência estrutural do documento não testa exportações DOCX/Pages, paginação visual, áudio do dispositivo nem interação real de navegador. O navegador do agente estava bloqueado; a interface publicada ainda precisa de execução real autenticada. A suite local verifica o mecanismo com simulações explicitamente identificadas.
