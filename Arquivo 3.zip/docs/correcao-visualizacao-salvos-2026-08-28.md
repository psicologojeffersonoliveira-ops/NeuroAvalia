# Visualização dos testes salvos — 2026-08-28

## Falha identificada
A conferência de respostas consultava somente `/api/professional/applications`. Registros presentes em `patient.tests` e `evaluations[].tests` não eram exibidos. O botão Visualizar abria apenas a prévia vazia do formulário.

## Correção
- Visualizar abre a conferência filtrada pelo instrumento do paciente e avaliação ativos.
- A conferência geral mostra também testes salvos localmente, independentemente de haver aplicação online.
- Cópias idênticas são apresentadas uma vez; cópias divergentes são mantidas separadas e identificadas pela origem. Não há fusão nem alteração dos dados.
- Seleção por IDs do paciente e da avaliação, nunca pelo nome. Registros explicitamente vinculados a outra identidade são excluídos da apresentação.
- Dados brutos, respostas e resultados armazenados são consultáveis em modo somente leitura. Nenhum motor é executado.
- A prévia do formulário continua disponível pelo botão Ver formulário de aplicação.
- Falha da consulta online não impede a apresentação dos registros locais.
- Traços só são apresentados quando foram efetivamente armazenados; resultados numéricos não são convertidos em traços inventados.

## Verificação
51 testes automatizados passaram nas 9 suítes de regressão selecionadas. Incluem seleção de fontes, homônimos, divergências, isolamento, cópia independente, ausência de mutação e apresentação local com falha de consulta online em DOM simulado.

O coletor foi executado também contra o backup enviado em 2026-08-28: BPA, AS, AD e AC-15 foram encontrados nos dois cadastros mencionados pelo usuário, com igualdade integral ao registro original. Backup permaneceu idêntico. Dados clínicos não foram copiados para o código nem para os testes.

Não foi realizado teste funcional em navegador real nesta intervenção. Não representa aprovação do percurso completo online → profissional → correção → laudo nem comprova ausência de todas as regressões. Autenticação, crivos, normas e cálculos não foram alterados.
