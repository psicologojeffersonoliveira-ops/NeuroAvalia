# Recuperação e salvamento automático — 2026-08-28

## Implementado
- Recuperação única dos cadastros solicitados que estiverem ausentes, por ID, a partir do backup enviado. Inclui os dois cadastros homônimos de Jefferson e as respectivas avaliações. Cadastros já existentes não são substituídos.
- Na ausência de base local e de cópia no servidor, inicialização pelo backup completo enviado (20 pacientes, 20 avaliações e 212 registros de agenda), não pelo HTML anterior.
- Base local existente arquivada antes da recuperação inicial.
- Snapshots clínicos imutáveis em armazenamento privado; ponteiro de revisão por profissional no banco. Novas revisões não apagam as anteriores.
- Hidratação aguarda o servidor antes de liberar o salvamento. Após confirmação, recupera também em outro navegador sem dados locais.
- Persistência existente passa a confirmar cópia local e servidor. Observação de alterações e verificação periódica cobrem mudanças no estado que não chamam explicitamente persist.
- Escritas serializadas e comparação atômica de revisão evitam sobrescrita por outra janela. Conflitos são bloqueados, não resolvidos por fusão automática.
- Falhas não são apresentadas como sucesso. Aviso antes de sair com alterações pendentes.
- HTML exportado aberto por file: conserva persistência local, sem depender do endpoint online.
- Endpoint exige autenticação e profissional responsável; backup não é um recurso público.

## Verificação
57 testes automatizados passaram antes da publicação, incluindo 6 novos casos de recuperação, integridade, autenticação, revisão concorrente, persistência e reabertura simulada. Recuperação também executada contra cópia do backup real: os quatro cadastros retornaram íntegros, incluindo testes, mantendo a origem inalterada.

Migração 0004: somente criação de tabela vazia de ponteiro de estado clínico; sem exclusões ou alterações nos registros existentes.

## Limites
Não houve teste funcional no navegador real. A recuperação na sessão do usuário ocorre na próxima abertura da área profissional. Publicação não confirma que essa sessão já executou a recuperação nem que houve gravação clínica real no servidor. Não é aprovação de todos os instrumentos nem do percurso completo até o laudo. Não foram alterados cálculos, crivos, normas ou a autenticação dos links de pacientes.
