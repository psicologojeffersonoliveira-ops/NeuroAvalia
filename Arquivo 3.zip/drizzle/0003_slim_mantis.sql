ALTER TABLE `online_applications` ADD `battery_id` text;--> statement-breakpoint
ALTER TABLE `online_applications` ADD `instrument_id` text;--> statement-breakpoint
ALTER TABLE `online_applications` ADD `protocol_id` text;--> statement-breakpoint
ALTER TABLE `online_applications` ADD `respondent_type` text;--> statement-breakpoint
ALTER TABLE `online_applications` ADD `form_spec_json` text;