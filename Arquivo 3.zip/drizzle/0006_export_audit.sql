CREATE TABLE IF NOT EXISTS `neuroavalia_export_logs` (
  `id` text PRIMARY KEY NOT NULL,
  `professional_email` text NOT NULL,
  `patient_id` text NOT NULL,
  `document_type` text NOT NULL,
  `format` text NOT NULL,
  `status` text NOT NULL,
  `build_version` text,
  `error_message` text,
  `created_at` integer NOT NULL
);
CREATE INDEX IF NOT EXISTS `neuroavalia_export_logs_owner_created_idx` ON `neuroavalia_export_logs` (`professional_email`,`created_at`);
