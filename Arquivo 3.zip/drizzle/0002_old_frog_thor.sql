CREATE TABLE `neuroavalia_active_html` (
	`professional_email` text PRIMARY KEY NOT NULL,
	`import_id` text NOT NULL,
	`object_key` text NOT NULL,
	`sha256` text NOT NULL,
	`previous_import_id` text,
	`previous_object_key` text,
	`previous_sha256` text,
	`activated_at` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `neuroavalia_imports` ADD `preservation_json` text;--> statement-breakpoint
ALTER TABLE `neuroavalia_imports` ADD `previous_import_id` text;--> statement-breakpoint
ALTER TABLE `neuroavalia_imports` ADD `previous_sha256` text;--> statement-breakpoint
ALTER TABLE `neuroavalia_imports` ADD `error_json` text;--> statement-breakpoint
ALTER TABLE `neuroavalia_imports` ADD `restored_at` integer;