CREATE TABLE `neuroavalia_clinical_state` (
	`professional_email` text PRIMARY KEY NOT NULL,
	`revision` text NOT NULL,
	`object_key` text NOT NULL,
	`updated_at` integer NOT NULL
);
