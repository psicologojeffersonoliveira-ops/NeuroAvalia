CREATE TABLE `neuroavalia_imports` (
	`import_id` text PRIMARY KEY NOT NULL,
	`professional_email` text NOT NULL,
	`kind` text NOT NULL,
	`file_name` text NOT NULL,
	`file_size` integer NOT NULL,
	`content_type` text NOT NULL,
	`sha256` text NOT NULL,
	`object_key` text NOT NULL,
	`status` text DEFAULT 'ANALISADO' NOT NULL,
	`analysis_json` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `neuroavalia_imports_object_key_unique` ON `neuroavalia_imports` (`object_key`);