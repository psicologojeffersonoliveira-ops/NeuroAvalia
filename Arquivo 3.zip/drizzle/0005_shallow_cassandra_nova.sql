ALTER TABLE `online_applications` ADD `identifier_name_hash` text;--> statement-breakpoint
ALTER TABLE `online_applications` ADD `identifier_cpf_hash` text;--> statement-breakpoint
ALTER TABLE `online_applications` ADD `identifier_birth_hash` text;