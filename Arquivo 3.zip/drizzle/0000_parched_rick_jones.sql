CREATE TABLE `online_applications` (
	`application_id` text PRIMARY KEY NOT NULL,
	`application_session_id` text NOT NULL,
	`patient_id` text NOT NULL,
	`evaluation_id` text NOT NULL,
	`test_id` text NOT NULL,
	`respondent_id` text,
	`professional_email` text NOT NULL,
	`identifier_hash` text NOT NULL,
	`token_hash` text NOT NULL,
	`access_key_hash` text,
	`status` text DEFAULT 'LIBERADA' NOT NULL,
	`application_mode` text DEFAULT 'AUTOPREENCHIMENTO_REMOTO' NOT NULL,
	`answers_json` text,
	`created_at` integer NOT NULL,
	`accessed_at` integer,
	`completed_at` integer,
	`expires_at` integer NOT NULL,
	`closed_at` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `online_applications_application_session_id_unique` ON `online_applications` (`application_session_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `online_applications_token_hash_unique` ON `online_applications` (`token_hash`);